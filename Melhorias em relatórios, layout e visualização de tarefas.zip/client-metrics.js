// Sistema de Métricas Detalhadas por Cliente
const renderClientMetrics = () => {
    return clientes.map(cliente => {
        const clienteTextos = textos.filter(t => t.clienteId === cliente.id);
        const clienteProjetos = projetos.filter(p => p.clienteId === cliente.id);
        const textosAtivos = clienteTextos.filter(t => !['entregue', 'upload_feito'].includes(t.status));
        const textosEntregues = clienteTextos.filter(t => ['entregue', 'upload_feito'].includes(t.status));
        const textosAtrasados = getOverdueTextsByClient(cliente.id);
        const projetosAtivos = clienteProjetos.filter(p => p.status === 'ativo');
        
        // Calcular métricas avançadas
        const taxaEntrega = clienteTextos.length > 0 ? Math.round((textosEntregues.length / clienteTextos.length) * 100) : 0;
        const mediaTempoEntrega = calculateAverageDeliveryTime(clienteTextos);
        const proximoPrazo = getNextDeadlineByClient(cliente.id);
        const valorMensal = calculateMonthlyValue(cliente.id);
        
        // Determinar status do cliente
        const clientStatus = determineClientStatus(textosAtrasados.length, textosAtivos.length, proximoPrazo);
        
        return `
            <div class="client-metric-card">
                <div class="client-metric-header">
                    <span class="client-metric-name">${cliente.nome}</span>
                    <span class="client-metric-status ${clientStatus.class}">${clientStatus.label}</span>
                </div>
                <div class="client-metric-stats">
                    <div class="client-metric-stat">
                        <span class="value">${clienteTextos.length}</span>
                        <span class="label">Total</span>
                    </div>
                    <div class="client-metric-stat">
                        <span class="value">${textosAtivos.length}</span>
                        <span class="label">Ativos</span>
                    </div>
                    <div class="client-metric-stat">
                        <span class="value">${textosEntregues.length}</span>
                        <span class="label">Entregues</span>
                    </div>
                    <div class="client-metric-stat">
                        <span class="value">${textosAtrasados.length}</span>
                        <span class="label">Atrasados</span>
                    </div>
                    <div class="client-metric-stat">
                        <span class="value">${projetosAtivos.length}</span>
                        <span class="label">Projetos</span>
                    </div>
                    <div class="client-metric-stat">
                        <span class="value">${taxaEntrega}%</span>
                        <span class="label">Taxa Entrega</span>
                    </div>
                </div>
                ${textosAtrasados.length > 0 ? `
                    <div class="client-delay-alert">
                        <span class="delay-count">${textosAtrasados.length}</span> texto(s) atrasado(s)
                        ${proximoPrazo ? ` • Próximo prazo: ${proximoPrazo.prazo}` : ''}
                    </div>
                ` : ''}
                <div class="client-metric-details">
                    <small>
                        ${mediaTempoEntrega ? `Tempo médio: ${mediaTempoEntrega} dias` : 'Sem dados de tempo'}
                        ${valorMensal ? ` • Valor mensal: R$ ${valorMensal.toLocaleString('pt-BR')}` : ''}
                    </small>
                </div>
            </div>
        `;
    }).join('');
};

// Obter textos atrasados por cliente
const getOverdueTextsByClient = (clienteId) => {
    const hoje = new Date();
    return textos.filter(texto => {
        if (texto.clienteId !== clienteId) return false;
        if (['entregue', 'upload_feito'].includes(texto.status)) return false;
        if (!texto.prazo) return false;
        return new Date(texto.prazo) < hoje;
    });
};

// Obter próximo prazo por cliente
const getNextDeadlineByClient = (clienteId) => {
    const hoje = new Date();
    const textosComPrazo = textos.filter(t => 
        t.clienteId === clienteId && 
        t.prazo && 
        !['entregue', 'upload_feito'].includes(t.status) &&
        new Date(t.prazo) >= hoje
    );
    
    if (textosComPrazo.length === 0) return null;
    
    return textosComPrazo.sort((a, b) => new Date(a.prazo) - new Date(b.prazo))[0];
};

// Calcular tempo médio de entrega
const calculateAverageDeliveryTime = (clienteTextos) => {
    const textosEntregues = clienteTextos.filter(t => 
        ['entregue', 'upload_feito'].includes(t.status) && 
        t.dataInicio && 
        t.dataEntrega
    );
    
    if (textosEntregues.length === 0) return null;
    
    const tempos = textosEntregues.map(t => {
        const inicio = new Date(t.dataInicio);
        const entrega = new Date(t.dataEntrega);
        return Math.ceil((entrega - inicio) / (1000 * 60 * 60 * 24));
    });
    
    const media = tempos.reduce((sum, tempo) => sum + tempo, 0) / tempos.length;
    return Math.round(media);
};

// Calcular valor mensal estimado
const calculateMonthlyValue = (clienteId) => {
    const cliente = clientes.find(c => c.id === clienteId);
    if (!cliente || !cliente.valorPorTexto) return null;
    
    const textosUltimoMes = textos.filter(t => {
        if (t.clienteId !== clienteId) return false;
        if (!t.dataEntrega) return false;
        
        const entrega = new Date(t.dataEntrega);
        const umMesAtras = new Date();
        umMesAtras.setMonth(umMesAtras.getMonth() - 1);
        
        return entrega >= umMesAtras;
    });
    
    return textosUltimoMes.length * cliente.valorPorTexto;
};

// Determinar status do cliente
const determineClientStatus = (atrasados, ativos, proximoPrazo) => {
    if (atrasados > 0) {
        return { class: 'atencao', label: 'Atenção' };
    }
    
    if (proximoPrazo) {
        const hoje = new Date();
        const prazo = new Date(proximoPrazo.prazo);
        const diasRestantes = Math.ceil((prazo - hoje) / (1000 * 60 * 60 * 24));
        
        if (diasRestantes <= 3) {
            return { class: 'atencao', label: 'Urgente' };
        }
    }
    
    if (ativos > 0) {
        return { class: 'ativo', label: 'Ativo' };
    }
    
    return { class: 'ativo', label: 'Normal' };
};

// Renderizar gráfico de comparação entre clientes
const renderClientComparisonChart = () => {
    const ctx = document.getElementById('clientComparisonChart');
    if (!ctx) return;
    
    const clienteData = clientes.map(cliente => {
        const clienteTextos = textos.filter(t => t.clienteId === cliente.id);
        const textosEntregues = clienteTextos.filter(t => ['entregue', 'upload_feito'].includes(t.status));
        const textosAtivos = clienteTextos.filter(t => !['entregue', 'upload_feito'].includes(t.status));
        
        return {
            nome: cliente.nome,
            entregues: textosEntregues.length,
            ativos: textosAtivos.length,
            total: clienteTextos.length
        };
    });
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: clienteData.map(c => c.nome),
            datasets: [
                {
                    label: 'Textos Entregues',
                    data: clienteData.map(c => c.entregues),
                    backgroundColor: '#90EE90'
                },
                {
                    label: 'Textos Ativos',
                    data: clienteData.map(c => c.ativos),
                    backgroundColor: '#4A67A1'
                }
            ]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    stacked: true
                },
                y: {
                    stacked: true,
                    beginAtZero: true
                }
            },
            plugins: {
                legend: {
                    position: 'top'
                },
                title: {
                    display: true,
                    text: 'Comparação de Textos por Cliente'
                }
            }
        }
    });
};

// Renderizar métricas de performance por cliente
const renderClientPerformanceMetrics = () => {
    return `
        <div class="performance-metrics">
            <h3>Performance por Cliente</h3>
            <div class="performance-grid">
                ${clientes.map(cliente => {
                    const clienteTextos = textos.filter(t => t.clienteId === cliente.id);
                    const textosEntregues = clienteTextos.filter(t => ['entregue', 'upload_feito'].includes(t.status));
                    const textosAtrasados = getOverdueTextsByClient(cliente.id);
                    const taxaEntrega = clienteTextos.length > 0 ? (textosEntregues.length / clienteTextos.length) * 100 : 0;
                    const taxaAtraso = clienteTextos.length > 0 ? (textosAtrasados.length / clienteTextos.length) * 100 : 0;
                    
                    return `
                        <div class="performance-card">
                            <h4>${cliente.nome}</h4>
                            <div class="performance-stats">
                                <div class="performance-stat">
                                    <span class="stat-label">Taxa de Entrega</span>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: ${taxaEntrega}%; background: #90EE90;"></div>
                                    </div>
                                    <span class="stat-value">${Math.round(taxaEntrega)}%</span>
                                </div>
                                <div class="performance-stat">
                                    <span class="stat-label">Taxa de Atraso</span>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: ${taxaAtraso}%; background: #DC143C;"></div>
                                    </div>
                                    <span class="stat-value">${Math.round(taxaAtraso)}%</span>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
};

// Adicionar métricas de performance ao dashboard
const addPerformanceMetricsToDashboard = () => {
    const dashboardView = document.getElementById('view');
    if (dashboardView && dashboardView.innerHTML.includes('Dashboards por Cliente')) {
        const performanceSection = document.createElement('div');
        performanceSection.className = 'view-section mt-4';
        performanceSection.innerHTML = renderClientPerformanceMetrics();
        dashboardView.appendChild(performanceSection);
    }
};


// Funcionalidades do Calendário Mensal
class CalendarManager {
    constructor() {
        this.currentDate = new Date();
        this.currentMonth = this.currentDate.getMonth();
        this.currentYear = this.currentDate.getFullYear();
        this.monthNames = [
            'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
            'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
        ];
        this.dayNames = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
    }

    renderCalendarView() {
        return `
            <div class="calendar-container">
                <div class="calendar-header">
                    <h2 id="calendarTitle">${this.monthNames[this.currentMonth]} ${this.currentYear}</h2>
                    <div class="calendar-nav">
                        <button id="prevMonth" class="btn btn-secondary">
                            <i class="fas fa-chevron-left"></i> Anterior
                        </button>
                        <button id="nextMonth" class="btn btn-secondary">
                            Próximo <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
                <div class="calendar-grid" id="calendarGrid">
                    ${this.generateCalendarGrid()}
                </div>
            </div>
            <div class="view-section mt-4">
                <h2>Tarefas do Mês</h2>
                <div class="task-filters mb-3">
                    <select id="statusFilter" class="form-control">
                        <option value="all">Todos os Status</option>
                        <option value="a_fazer">A Fazer</option>
                        <option value="em_andamento">Em Andamento</option>
                        <option value="feito">Feito</option>
                        <option value="revisado">Revisado</option>
                        <option value="entregue">Entregue</option>
                        <option value="upload_feito">Upload Feito</option>
                    </select>
                </div>
                <div id="monthlyTasksList"></div>
            </div>
        `;
    }

    generateCalendarGrid() {
        let html = '';
        
        // Cabeçalho dos dias da semana
        this.dayNames.forEach(day => {
            html += `<div class="calendar-day-name">${day}</div>`;
        });

        // Primeiro dia do mês e último dia do mês anterior
        const firstDay = new Date(this.currentYear, this.currentMonth, 1);
        const lastDay = new Date(this.currentYear, this.currentMonth + 1, 0);
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());

        // Gerar 42 dias (6 semanas)
        for (let i = 0; i < 42; i++) {
            const currentDate = new Date(startDate);
            currentDate.setDate(startDate.getDate() + i);
            
            const isCurrentMonth = currentDate.getMonth() === this.currentMonth;
            const isToday = this.isToday(currentDate);
            const dayTasks = this.getTasksForDate(currentDate);
            
            let dayClass = 'calendar-day';
            if (isCurrentMonth) dayClass += ' current-month';
            if (isToday) dayClass += ' today';

            html += `
                <div class="${dayClass}" data-date="${currentDate.toISOString().split('T')[0]}">
                    <div class="calendar-day-number">${currentDate.getDate()}</div>
                    <div class="calendar-day-tasks">
                        ${dayTasks.map(task => `
                            <div class="calendar-task-item status-${task.status}" title="${task.titulo}">
                                ${task.titulo.length > 15 ? task.titulo.substring(0, 15) + '...' : task.titulo}
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        return html;
    }

    getTasksForDate(date) {
        const dateStr = date.toISOString().split('T')[0];
        return textos.filter(texto => texto.prazo === dateStr);
    }

    isToday(date) {
        const today = new Date();
        return date.toDateString() === today.toDateString();
    }

    previousMonth() {
        this.currentMonth--;
        if (this.currentMonth < 0) {
            this.currentMonth = 11;
            this.currentYear--;
        }
        this.updateCalendar();
    }

    nextMonth() {
        this.currentMonth++;
        if (this.currentMonth > 11) {
            this.currentMonth = 0;
            this.currentYear++;
        }
        this.updateCalendar();
    }

    updateCalendar() {
        document.getElementById('calendarTitle').innerText = `${this.monthNames[this.currentMonth]} ${this.currentYear}`;
        document.getElementById('calendarGrid').innerHTML = this.generateCalendarGrid();
        this.renderMonthlyTasksList();
    }

    renderMonthlyTasksList() {
        const startOfMonth = new Date(this.currentYear, this.currentMonth, 1);
        const endOfMonth = new Date(this.currentYear, this.currentMonth + 1, 0);
        
        const monthlyTasks = textos.filter(texto => {
            if (!texto.prazo) return false;
            const taskDate = new Date(texto.prazo);
            return taskDate >= startOfMonth && taskDate <= endOfMonth;
        });

        const statusFilter = document.getElementById('statusFilter')?.value || 'all';
        const filteredTasks = statusFilter === 'all' ? monthlyTasks : monthlyTasks.filter(t => t.status === statusFilter);

        const tasksList = document.getElementById('monthlyTasksList');
        if (!tasksList) return;

        if (filteredTasks.length === 0) {
            tasksList.innerHTML = '<p class="text-muted">Nenhuma tarefa encontrada para este período.</p>';
            return;
        }

        tasksList.innerHTML = filteredTasks.map(task => {
            const cliente = clientes.find(c => c.id === task.clienteId);
            const redator = redatores.find(r => r.id === task.redatorId);
            
            return `
                <div class="task-list-item">
                    <div class="task-list-item-details">
                        <h4>${task.titulo}</h4>
                        <p><strong>Cliente:</strong> ${cliente?.nome || 'N/A'} | <strong>Redator:</strong> ${redator?.nome || 'N/A'}</p>
                        <p><strong>Prazo:</strong> ${new Date(task.prazo).toLocaleDateString('pt-BR')} | <strong>Upload:</strong> ${task.uploadDone ? 'Concluído' : 'Pendente'}</p>
                        ${task.notas ? `<p><strong>Notas:</strong> ${task.notas}</p>` : ''}
                    </div>
                    <div class="task-list-item-actions">
                        <span class="task-status-badge ${task.status}">${task.status.replace('_', ' ').toUpperCase()}</span>
                        <button class="btn btn-sm btn-secondary" onclick="editTexto('${task.id}')">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteTexto('${task.id}')">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    initializeEventListeners() {
        document.getElementById('prevMonth')?.addEventListener('click', () => this.previousMonth());
        document.getElementById('nextMonth')?.addEventListener('click', () => this.nextMonth());
        document.getElementById('statusFilter')?.addEventListener('change', () => this.renderMonthlyTasksList());
    }
}

// Instância global do calendário
window.calendarManager = new CalendarManager();


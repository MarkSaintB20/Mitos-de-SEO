// Nova estrutura de dados para suportar projetos por cliente
class DataManager {
    constructor() {
        this.initializeData();
    }

    initializeData() {
        // Estrutura de dados aprimorada
        this.clientes = [
            {
                id: 'c1',
                nome: 'Cliente A',
                contato: 'cliente.a@email.com',
                resumo: 'Cliente focado em conteúdo de tecnologia e inovação.',
                observacoes: 'Cliente preferencial, sempre pontual nos pagamentos.',
                documentos: [],
                projetos: ['p1', 'p3']
            },
            {
                id: 'c2',
                nome: 'Cliente B',
                contato: 'cliente.b@email.com',
                resumo: 'Empresa de marketing digital especializada em e-commerce.',
                observacoes: 'Requer revisões frequentes, mas paga bem.',
                documentos: [],
                projetos: ['p2', 'p4']
            }
        ];

        this.projetos = [
            {
                id: 'p1',
                nome: 'Projeto Tech Blog',
                clienteId: 'c1',
                descricao: 'Blog corporativo sobre tecnologia e inovação',
                dataInicio: '2025-01-01',
                dataFim: '2025-12-31',
                status: 'ativo',
                resumo: 'Projeto de blog corporativo com foco em artigos técnicos e tendências de mercado.',
                observacoes: 'Cliente solicita artigos semanais de 1500 palavras.',
                documentos: [],
                textos: ['t1', 't3', 't5']
            },
            {
                id: 'p2',
                nome: 'Campanha E-commerce',
                clienteId: 'c2',
                descricao: 'Conteúdo para campanha de marketing digital',
                dataInicio: '2025-02-01',
                dataFim: '2025-08-31',
                status: 'ativo',
                resumo: 'Campanha completa de marketing digital incluindo ebooks, posts e materiais promocionais.',
                observacoes: 'Foco em conversão e vendas. Tom mais comercial.',
                documentos: [],
                textos: ['t2', 't6']
            },
            {
                id: 'p3',
                nome: 'Relatórios Anuais',
                clienteId: 'c1',
                descricao: 'Relatórios corporativos anuais',
                dataInicio: '2025-07-01',
                dataFim: '2025-09-30',
                status: 'ativo',
                resumo: 'Produção de relatórios anuais e documentos corporativos.',
                observacoes: 'Requer aprovação da diretoria antes da publicação.',
                documentos: [],
                textos: []
            },
            {
                id: 'p4',
                nome: 'Conteúdo Redes Sociais',
                clienteId: 'c2',
                descricao: 'Posts e conteúdo para redes sociais',
                dataInicio: '2025-03-01',
                dataFim: '2025-12-31',
                status: 'ativo',
                resumo: 'Criação de conteúdo para Instagram, Facebook e LinkedIn.',
                observacoes: 'Posts diários, stories semanais.',
                documentos: [],
                textos: []
            }
        ];

        this.redatores = [
            {
                id: 'r1',
                nome: 'Redator X',
                especialidade: 'SEO',
                email: 'redator.x@email.com',
                telefone: '(11) 99999-9999',
                projetos: ['p1', 'p3']
            },
            {
                id: 'r2',
                nome: 'Redator Y',
                especialidade: 'Marketing',
                email: 'redator.y@email.com',
                telefone: '(11) 88888-8888',
                projetos: ['p2', 'p4']
            }
        ];

        this.textos = [
            {
                id: 't1',
                titulo: 'Artigo sobre IA',
                clienteId: 'c1',
                projetoId: 'p1',
                redatorId: 'r1',
                prazo: '2025-08-15',
                status: 'a_fazer',
                uploadBy: 'B20',
                uploadDone: false,
                onDemand: false,
                notas: 'Artigo técnico sobre inteligência artificial e suas aplicações no mercado.',
                palavrasChave: ['IA', 'tecnologia', 'inovação'],
                numerosPalavras: 1500,
                revisoes: []
            },
            {
                id: 't2',
                titulo: 'Ebook de Vendas',
                clienteId: 'c2',
                projetoId: 'p2',
                redatorId: 'r2',
                prazo: '2025-08-20',
                status: 'em_andamento',
                uploadBy: 'B20',
                uploadDone: false,
                onDemand: true,
                notas: 'Ebook focado em estratégias de vendas para e-commerce. Urgente!',
                palavrasChave: ['vendas', 'e-commerce', 'conversão'],
                numerosPalavras: 3000,
                revisoes: [
                    {
                        data: '2025-08-05',
                        revisor: 'Marco Antônio',
                        comentarios: 'Adicionar mais exemplos práticos'
                    }
                ]
            },
            {
                id: 't3',
                titulo: 'Post para Blog',
                clienteId: 'c1',
                projetoId: 'p1',
                redatorId: 'r1',
                prazo: '2025-08-05',
                status: 'feito',
                uploadBy: 'B20',
                uploadDone: false,
                onDemand: false,
                notas: 'Post sobre tendências tecnológicas para o blog corporativo.',
                palavrasChave: ['tendências', 'tecnologia', 'futuro'],
                numerosPalavras: 800,
                revisoes: []
            },
            {
                id: 't4',
                titulo: 'Case Study',
                clienteId: 'c2',
                projetoId: 'p2',
                redatorId: 'r2',
                prazo: '2025-07-25',
                status: 'entregue',
                uploadBy: 'B20',
                uploadDone: true,
                onDemand: false,
                notas: 'Case study de sucesso de cliente do e-commerce.',
                palavrasChave: ['case study', 'sucesso', 'resultados'],
                numerosPalavras: 2000,
                revisoes: [
                    {
                        data: '2025-07-20',
                        revisor: 'Marco Antônio',
                        comentarios: 'Aprovado sem alterações'
                    }
                ]
            },
            {
                id: 't5',
                titulo: 'Relatório Anual',
                clienteId: 'c1',
                projetoId: 'p1',
                redatorId: 'r1',
                prazo: '2025-08-10',
                status: 'revisado',
                uploadBy: 'B20',
                uploadDone: false,
                onDemand: false,
                notas: 'Relatório anual da empresa com métricas e resultados. Aguardando feedback da diretoria.',
                palavrasChave: ['relatório', 'anual', 'métricas'],
                numerosPalavras: 5000,
                revisoes: [
                    {
                        data: '2025-08-08',
                        revisor: 'Marco Antônio',
                        comentarios: 'Revisar seção de métricas financeiras'
                    }
                ]
            },
            {
                id: 't6',
                titulo: 'Infográfico',
                clienteId: 'c2',
                projetoId: 'p2',
                redatorId: 'r2',
                prazo: '2025-08-12',
                status: 'upload_feito',
                uploadBy: 'B20',
                uploadDone: true,
                onDemand: false,
                notas: 'Infográfico sobre estatísticas de e-commerce. Publicado no site do cliente.',
                palavrasChave: ['infográfico', 'estatísticas', 'visual'],
                numerosPalavras: 500,
                revisoes: []
            }
        ];

        this.guestPosts = [
            {
                id: 'gp1',
                titulo: 'Guia de SEO Avançado',
                clienteId: 'c1',
                projetoId: 'p1',
                url: 'https://blogparceiro.com/seo-avancado',
                dataPublicacao: '2025-07-01',
                status: 'publicado',
                domainAuthority: 60,
                backlink: 'https://seusite.com/pagina-seo',
                notas: 'Guest post em blog de alta autoridade sobre SEO.',
                palavrasChave: ['SEO', 'otimização', 'ranking']
            }
        ];

        this.documentos = [
            {
                id: 'd1',
                nome: 'Brief Projeto Tech Blog.pdf',
                tipo: 'pdf',
                tamanho: '2.5MB',
                dataUpload: '2025-01-15',
                clienteId: 'c1',
                projetoId: 'p1',
                url: '/documentos/brief-tech-blog.pdf',
                descricao: 'Brief detalhado do projeto de blog corporativo'
            },
            {
                id: 'd2',
                nome: 'Guia de Estilo.docx',
                tipo: 'docx',
                tamanho: '1.2MB',
                dataUpload: '2025-02-01',
                clienteId: 'c2',
                projetoId: 'p2',
                url: '/documentos/guia-estilo.docx',
                descricao: 'Guia de estilo e tom de voz para campanhas'
            }
        ];
    }

    // Métodos para gerenciar dados
    getClienteById(id) {
        return this.clientes.find(c => c.id === id);
    }

    getProjetoById(id) {
        return this.projetos.find(p => p.id === id);
    }

    getProjetosByCliente(clienteId) {
        return this.projetos.filter(p => p.clienteId === clienteId);
    }

    getTextosByProjeto(projetoId) {
        return this.textos.filter(t => t.projetoId === projetoId);
    }

    getTextosByCliente(clienteId) {
        return this.textos.filter(t => t.clienteId === clienteId);
    }

    getDocumentosByProjeto(projetoId) {
        return this.documentos.filter(d => d.projetoId === projetoId);
    }

    // Métodos para estatísticas
    getClienteStats(clienteId) {
        const textos = this.getTextosByCliente(clienteId);
        const projetos = this.getProjetosByCliente(clienteId);
        
        return {
            totalTextos: textos.length,
            textosAtivos: textos.filter(t => !['entregue', 'upload_feito'].includes(t.status)).length,
            textosEntregues: textos.filter(t => ['entregue', 'upload_feito'].includes(t.status)).length,
            totalProjetos: projetos.length,
            projetosAtivos: projetos.filter(p => p.status === 'ativo').length,
            statusDistribution: this.getStatusDistribution(textos),
            proximosPrazos: this.getProximosPrazos(textos)
        };
    }

    getStatusDistribution(textos) {
        const distribution = {};
        textos.forEach(t => {
            distribution[t.status] = (distribution[t.status] || 0) + 1;
        });
        return distribution;
    }

    getProximosPrazos(textos) {
        const hoje = new Date();
        const proximosPrazos = textos
            .filter(t => t.prazo && !['entregue', 'upload_feito'].includes(t.status))
            .map(t => ({
                ...t,
                diasRestantes: Math.ceil((new Date(t.prazo) - hoje) / (1000 * 60 * 60 * 24))
            }))
            .sort((a, b) => a.diasRestantes - b.diasRestantes);
        
        return proximosPrazos.slice(0, 5); // Próximos 5 prazos
    }

    // Métodos para adicionar/editar dados
    addProjeto(projeto) {
        projeto.id = 'p' + (this.projetos.length + 1);
        this.projetos.push(projeto);
        return projeto;
    }

    updateProjeto(id, updates) {
        const index = this.projetos.findIndex(p => p.id === id);
        if (index !== -1) {
            this.projetos[index] = { ...this.projetos[index], ...updates };
            return this.projetos[index];
        }
        return null;
    }

    addDocumento(documento) {
        documento.id = 'd' + (this.documentos.length + 1);
        documento.dataUpload = new Date().toISOString().split('T')[0];
        this.documentos.push(documento);
        return documento;
    }

    updateTextoNotas(textoId, notas) {
        const texto = this.textos.find(t => t.id === textoId);
        if (texto) {
            texto.notas = notas;
            return texto;
        }
        return null;
    }

    addRevisao(textoId, revisao) {
        const texto = this.textos.find(t => t.id === textoId);
        if (texto) {
            if (!texto.revisoes) texto.revisoes = [];
            revisao.data = new Date().toISOString().split('T')[0];
            texto.revisoes.push(revisao);
            return texto;
        }
        return null;
    }
}

// Instância global do gerenciador de dados
window.dataManager = new DataManager();


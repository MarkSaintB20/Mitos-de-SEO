// Sistema de Upload de Arquivos Reais
class FileUploadManager {
    constructor() {
        this.uploadedFiles = JSON.parse(localStorage.getItem('uploadedFiles')) || {};
        this.maxFileSize = 10 * 1024 * 1024; // 10MB
        this.allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'application/vnd.ms-powerpoint',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation',
            'text/plain',
            'image/jpeg',
            'image/png',
            'image/gif',
            'application/zip',
            'application/x-rar-compressed'
        ];
    }

    // Criar input de upload
    createUploadInput(projectId, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const uploadSection = document.createElement('div');
        uploadSection.className = 'file-upload-section';
        uploadSection.innerHTML = `
            <div class="upload-area" id="uploadArea_${projectId}">
                <div class="upload-icon">📁</div>
                <p>Arraste arquivos aqui ou clique para selecionar</p>
                <p class="upload-info">Máximo 10MB por arquivo</p>
                <input type="file" id="fileInput_${projectId}" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.jpg,.jpeg,.png,.gif,.zip,.rar" style="display: none;">
                <button class="btn btn-primary" onclick="document.getElementById('fileInput_${projectId}').click()">
                    Selecionar Arquivos
                </button>
            </div>
            <div class="upload-progress" id="uploadProgress_${projectId}" style="display: none;">
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill_${projectId}"></div>
                </div>
                <span class="progress-text" id="progressText_${projectId}">0%</span>
            </div>
            <div class="uploaded-files" id="uploadedFiles_${projectId}">
                ${this.renderUploadedFiles(projectId)}
            </div>
        `;

        container.appendChild(uploadSection);
        this.setupEventListeners(projectId);
    }

    // Configurar event listeners
    setupEventListeners(projectId) {
        const uploadArea = document.getElementById(`uploadArea_${projectId}`);
        const fileInput = document.getElementById(`fileInput_${projectId}`);

        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('drag-over');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('drag-over');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('drag-over');
            const files = Array.from(e.dataTransfer.files);
            this.handleFiles(files, projectId);
        });

        // File input change
        fileInput.addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            this.handleFiles(files, projectId);
        });
    }

    // Processar arquivos
    handleFiles(files, projectId) {
        files.forEach(file => {
            if (this.validateFile(file)) {
                this.uploadFile(file, projectId);
            }
        });
    }

    // Validar arquivo
    validateFile(file) {
        if (file.size > this.maxFileSize) {
            this.showError(`Arquivo "${file.name}" é muito grande. Máximo 10MB.`);
            return false;
        }

        if (!this.allowedTypes.includes(file.type)) {
            this.showError(`Tipo de arquivo "${file.name}" não permitido.`);
            return false;
        }

        return true;
    }

    // Simular upload de arquivo
    uploadFile(file, projectId) {
        const fileId = this.generateFileId();
        const progressFill = document.getElementById(`progressFill_${projectId}`);
        const progressText = document.getElementById(`progressText_${projectId}`);
        const progressContainer = document.getElementById(`uploadProgress_${projectId}`);

        progressContainer.style.display = 'block';

        // Simular progresso de upload
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 15;
            if (progress > 100) progress = 100;

            progressFill.style.width = progress + '%';
            progressText.textContent = Math.round(progress) + '%';

            if (progress >= 100) {
                clearInterval(interval);
                setTimeout(() => {
                    this.saveFile(file, fileId, projectId);
                    progressContainer.style.display = 'none';
                    this.refreshFileList(projectId);
                }, 500);
            }
        }, 100);
    }

    // Salvar arquivo no localStorage (simulação)
    saveFile(file, fileId, projectId) {
        if (!this.uploadedFiles[projectId]) {
            this.uploadedFiles[projectId] = [];
        }

        const fileData = {
            id: fileId,
            name: file.name,
            size: file.size,
            type: file.type,
            uploadDate: new Date().toISOString(),
            url: URL.createObjectURL(file) // Para preview/download
        };

        this.uploadedFiles[projectId].push(fileData);
        localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles));
        
        this.showSuccess(`Arquivo "${file.name}" enviado com sucesso!`);
    }

    // Renderizar lista de arquivos
    renderUploadedFiles(projectId) {
        const files = this.uploadedFiles[projectId] || [];
        if (files.length === 0) {
            return '<p class="no-files">Nenhum arquivo enviado ainda.</p>';
        }

        return files.map(file => `
            <div class="file-item" data-file-id="${file.id}">
                <div class="file-info">
                    <div class="file-icon">${this.getFileIcon(file.type)}</div>
                    <div class="file-details">
                        <h5>${file.name}</h5>
                        <p>${this.formatFileSize(file.size)} • ${this.formatDate(file.uploadDate)}</p>
                    </div>
                </div>
                <div class="file-actions">
                    <button class="btn btn-sm btn-secondary" onclick="fileUploadManager.downloadFile('${file.id}', '${projectId}')">
                        📥 Download
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="fileUploadManager.deleteFile('${file.id}', '${projectId}')">
                        🗑️ Excluir
                    </button>
                </div>
            </div>
        `).join('');
    }

    // Atualizar lista de arquivos
    refreshFileList(projectId) {
        const container = document.getElementById(`uploadedFiles_${projectId}`);
        if (container) {
            container.innerHTML = this.renderUploadedFiles(projectId);
        }
    }

    // Download de arquivo
    downloadFile(fileId, projectId) {
        const files = this.uploadedFiles[projectId] || [];
        const file = files.find(f => f.id === fileId);
        
        if (file) {
            const link = document.createElement('a');
            link.href = file.url;
            link.download = file.name;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }

    // Excluir arquivo
    deleteFile(fileId, projectId) {
        if (confirm('Tem certeza que deseja excluir este arquivo?')) {
            const files = this.uploadedFiles[projectId] || [];
            this.uploadedFiles[projectId] = files.filter(f => f.id !== fileId);
            localStorage.setItem('uploadedFiles', JSON.stringify(this.uploadedFiles));
            this.refreshFileList(projectId);
            this.showSuccess('Arquivo excluído com sucesso!');
        }
    }

    // Utilitários
    generateFileId() {
        return 'file_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    getFileIcon(type) {
        const iconMap = {
            'application/pdf': '📄',
            'application/msword': '📝',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '📝',
            'application/vnd.ms-excel': '📊',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '📊',
            'application/vnd.ms-powerpoint': '📽️',
            'application/vnd.openxmlformats-officedocument.presentationml.presentation': '📽️',
            'text/plain': '📄',
            'image/jpeg': '🖼️',
            'image/png': '🖼️',
            'image/gif': '🖼️',
            'application/zip': '📦',
            'application/x-rar-compressed': '📦'
        };
        return iconMap[type] || '📁';
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR', {hour: '2-digit', minute: '2-digit'});
    }

    showSuccess(message) {
        this.showNotification(message, 'success');
    }

    showError(message) {
        this.showNotification(message, 'error');
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
}

// Instância global
const fileUploadManager = new FileUploadManager();


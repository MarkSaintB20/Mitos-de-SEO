// Sistema de Gerenciamento de Atrasos
class DelayManager {
    constructor() {
        this.delayThresholds = {
            urgent: 0,      // Já passou do prazo
            warning: 3,     // 3 dias ou menos
            attention: 7    // 7 dias ou menos
        };
    }

    // Renderizar página de atrasos
    renderDelaysPage() {
        const delayedTexts = this.getDelayedTexts();
        const upcomingDeadlines = this.getUpcomingDeadlines();
        const delayStats = this.getDelayStatistics();

        return `
            <div class="delays-page">
                <div class="delays-header">
                    <h2>Gestão de Atrasos e Prazos</h2>
                    <div class="delays-summary">
                        <div class="delay-stat urgent">
                            <span class="stat-number">${delayStats.overdue}</span>
                            <span class="stat-label">Atrasados</span>
                        </div>
                        <div class="delay-stat warning">
                            <span class="stat-number">${delayStats.urgent}</span>
                            <span class="stat-label">Urgentes</span>
                        </div>
                        <div class="delay-stat attention">
                            <span class="stat-number">${delayStats.upcoming}</span>
                            <span class="stat-label">Próximos</span>
                        </div>
                    </div>
                </div>

                <div class="delays-filters">
                    <div class="filter-group">
                        <label for="delayClientFilter">Cliente</label>
                        <select id="delayClientFilter" onchange="delayManager.filterDelays()">
                            <option value="">Todos os Clientes</option>
                            ${clientes.map(c => `<option value="${c.id}">${c.nome}</option>`).join('')}
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="delayProjectFilter">Projeto</label>
                        <select id="delayProjectFilter" onchange="delayManager.filterDelays()">
                            <option value="">Todos os Projetos</option>
                            ${projetos.map(p => `<option value="${p.id}">${p.nome}</option>`).join('')}
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="delayRedatorFilter">Redator</label>
                        <select id="delayRedatorFilter" onchange="delayManager.filterDelays()">
                            <option value="">Todos os Redatores</option>
                            ${redatores.map(r => `<option value="${r.id}">${r.nome}</option>`).join('')}
                        </select>
                    </div>
                    <div class="filter-group">
                        <label for="delayStatusFilter">Status</label>
                        <select id="delayStatusFilter" onchange="delayManager.filterDelays()">
                            <option value="">Todos os Status</option>
                            <option value="overdue">Atrasados</option>
                            <option value="urgent">Urgentes (≤3 dias)</option>
                            <option value="upcoming">Próximos (≤7 dias)</option>
                        </select>
                    </div>
                </div>

                <div class="delays-content">
                    <div class="delays-section">
                        <h3>Textos Atrasados</h3>
                        <div class="delays-list" id="overdueList">
                            ${this.renderDelayedTextsList(delayedTexts.overdue, 'overdue')}
                        </div>
                    </div>

                    <div class="delays-section">
                        <h3>Prazos Urgentes (≤3 dias)</h3>
                        <div class="delays-list" id="urgentList">
                            ${this.renderDelayedTextsList(delayedTexts.urgent, 'urgent')}
                        </div>
                    </div>

                    <div class="delays-section">
                        <h3>Próximos Prazos (≤7 dias)</h3>
                        <div class="delays-list" id="upcomingList">
                            ${this.renderDelayedTextsList(delayedTexts.upcoming, 'upcoming')}
                        </div>
                    </div>
                </div>

                <div class="delays-actions">
                    <button class="btn btn-primary" onclick="delayManager.sendDelayNotifications()">
                        📧 Enviar Notificações
                    </button>
                    <button class="btn btn-secondary" onclick="delayManager.exportDelayReport()">
                        📊 Exportar Relatório
                    </button>
                    <button class="btn btn-warning" onclick="delayManager.bulkUpdateDeadlines()">
                        📅 Atualizar Prazos em Lote
                    </button>
                </div>
            </div>
        `;
    }

    // Obter textos atrasados e próximos ao prazo
    getDelayedTexts() {
        const hoje = new Date();
        const result = {
            overdue: [],
            urgent: [],
            upcoming: []
        };

        textos.filter(t => !['entregue', 'upload_feito'].includes(t.status) && t.prazo).forEach(texto => {
            const prazo = new Date(texto.prazo);
            const diffDays = Math.ceil((prazo - hoje) / (1000 * 60 * 60 * 24));

            if (diffDays < 0) {
                result.overdue.push({...texto, daysOverdue: Math.abs(diffDays)});
            } else if (diffDays <= this.delayThresholds.warning) {
                result.urgent.push({...texto, daysLeft: diffDays});
            } else if (diffDays <= this.delayThresholds.attention) {
                result.upcoming.push({...texto, daysLeft: diffDays});
            }
        });

        // Ordenar por prioridade
        result.overdue.sort((a, b) => b.daysOverdue - a.daysOverdue);
        result.urgent.sort((a, b) => a.daysLeft - b.daysLeft);
        result.upcoming.sort((a, b) => a.daysLeft - b.daysLeft);

        return result;
    }

    // Obter próximos prazos
    getUpcomingDeadlines() {
        const hoje = new Date();
        return textos
            .filter(t => t.prazo && !['entregue', 'upload_feito'].includes(t.status))
            .map(t => ({
                ...t,
                daysLeft: Math.ceil((new Date(t.prazo) - hoje) / (1000 * 60 * 60 * 24))
            }))
            .sort((a, b) => a.daysLeft - b.daysLeft)
            .slice(0, 10);
    }

    // Obter estatísticas de atrasos
    getDelayStatistics() {
        const delayed = this.getDelayedTexts();
        return {
            overdue: delayed.overdue.length,
            urgent: delayed.urgent.length,
            upcoming: delayed.upcoming.length,
            total: delayed.overdue.length + delayed.urgent.length + delayed.upcoming.length
        };
    }

    // Renderizar lista de textos atrasados
    renderDelayedTextsList(texts, type) {
        if (texts.length === 0) {
            return `<div class="no-delays">Nenhum texto nesta categoria.</div>`;
        }

        return texts.map(texto => {
            const cliente = clientes.find(c => c.id === texto.clienteId);
            const projeto = projetos.find(p => p.id === texto.projetoId);
            const redator = redatores.find(r => r.id === texto.redatorId);

            const delayInfo = type === 'overdue' 
                ? `<span class="delay-info overdue">${texto.daysOverdue} dias atrasado</span>`
                : `<span class="delay-info ${type}">${texto.daysLeft} dias restantes</span>`;

            return `
                <div class="delay-item ${type}" data-texto-id="${texto.id}">
                    <div class="delay-content">
                        <div class="delay-header">
                            <h4>${texto.titulo}</h4>
                            ${delayInfo}
                        </div>
                        <div class="delay-details">
                            <div class="delay-meta">
                                <span><strong>Cliente:</strong> ${cliente?.nome || 'N/A'}</span>
                                <span><strong>Projeto:</strong> ${projeto?.nome || 'N/A'}</span>
                                <span><strong>Redator:</strong> ${redator?.nome || 'N/A'}</span>
                                <span><strong>Prazo:</strong> ${new Date(texto.prazo).toLocaleDateString('pt-BR')}</span>
                                <span><strong>Status:</strong> <span class="status-badge ${texto.status}">${this.getStatusLabel(texto.status)}</span></span>
                            </div>
                            ${texto.observacoes ? `<div class="delay-notes"><strong>Observações:</strong> ${texto.observacoes}</div>` : ''}
                        </div>
                    </div>
                    <div class="delay-actions">
                        <button class="btn btn-sm btn-primary" onclick="delayManager.editDeadline('${texto.id}')">
                            📅 Alterar Prazo
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="delayManager.addDelayNote('${texto.id}')">
                            📝 Adicionar Nota
                        </button>
                        <button class="btn btn-sm btn-success" onclick="delayManager.markAsCompleted('${texto.id}')">
                            ✅ Marcar Concluído
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Filtrar atrasos
    filterDelays() {
        const clienteId = document.getElementById('delayClientFilter').value;
        const projetoId = document.getElementById('delayProjectFilter').value;
        const redatorId = document.getElementById('delayRedatorFilter').value;
        const statusFilter = document.getElementById('delayStatusFilter').value;

        // Aplicar filtros e re-renderizar listas
        const delayedTexts = this.getDelayedTexts();
        
        // Filtrar por critérios
        Object.keys(delayedTexts).forEach(category => {
            delayedTexts[category] = delayedTexts[category].filter(texto => {
                if (clienteId && texto.clienteId !== clienteId) return false;
                if (projetoId && texto.projetoId !== projetoId) return false;
                if (redatorId && texto.redatorId !== redatorId) return false;
                return true;
            });
        });

        // Atualizar listas
        if (!statusFilter || statusFilter === 'overdue') {
            document.getElementById('overdueList').innerHTML = this.renderDelayedTextsList(delayedTexts.overdue, 'overdue');
        }
        if (!statusFilter || statusFilter === 'urgent') {
            document.getElementById('urgentList').innerHTML = this.renderDelayedTextsList(delayedTexts.urgent, 'urgent');
        }
        if (!statusFilter || statusFilter === 'upcoming') {
            document.getElementById('upcomingList').innerHTML = this.renderDelayedTextsList(delayedTexts.upcoming, 'upcoming');
        }
    }

    // Editar prazo
    editDeadline(textoId) {
        const texto = textos.find(t => t.id === textoId);
        if (!texto) return;

        const newDeadline = prompt('Nova data de prazo (YYYY-MM-DD):', texto.prazo);
        if (newDeadline && this.isValidDate(newDeadline)) {
            texto.prazo = newDeadline;
            this.saveData();
            this.refreshDelaysPage();
            this.showNotification('Prazo atualizado com sucesso!', 'success');
        }
    }

    // Adicionar nota de atraso
    addDelayNote(textoId) {
        const texto = textos.find(t => t.id === textoId);
        if (!texto) return;

        const note = prompt('Adicionar observação sobre o atraso:');
        if (note) {
            if (!texto.observacoes) texto.observacoes = '';
            texto.observacoes += `\n[${new Date().toLocaleDateString('pt-BR')}] ${note}`;
            this.saveData();
            this.refreshDelaysPage();
            this.showNotification('Observação adicionada!', 'success');
        }
    }

    // Marcar como concluído
    markAsCompleted(textoId) {
        const texto = textos.find(t => t.id === textoId);
        if (!texto) return;

        if (confirm('Marcar este texto como entregue?')) {
            texto.status = 'entregue';
            this.saveData();
            this.refreshDelaysPage();
            this.showNotification('Texto marcado como entregue!', 'success');
        }
    }

    // Enviar notificações
    sendDelayNotifications() {
        const delayStats = this.getDelayStatistics();
        alert(`Notificações enviadas!\n\nResumo:\n- ${delayStats.overdue} textos atrasados\n- ${delayStats.urgent} textos urgentes\n- ${delayStats.upcoming} próximos prazos`);
    }

    // Exportar relatório
    exportDelayReport() {
        const delayedTexts = this.getDelayedTexts();
        const report = this.generateDelayReport(delayedTexts);
        this.downloadReport(report, 'relatorio_atrasos.txt');
    }

    // Atualizar prazos em lote
    bulkUpdateDeadlines() {
        const days = prompt('Quantos dias adicionar a todos os prazos pendentes?');
        if (days && !isNaN(days)) {
            const daysToAdd = parseInt(days);
            let updated = 0;
            
            textos.forEach(texto => {
                if (!['entregue', 'upload_feito'].includes(texto.status) && texto.prazo) {
                    const currentDate = new Date(texto.prazo);
                    currentDate.setDate(currentDate.getDate() + daysToAdd);
                    texto.prazo = currentDate.toISOString().split('T')[0];
                    updated++;
                }
            });
            
            this.saveData();
            this.refreshDelaysPage();
            this.showNotification(`${updated} prazos atualizados!`, 'success');
        }
    }

    // Utilitários
    getStatusLabel(status) {
        const labels = {
            'a_fazer': 'A Fazer',
            'em_andamento': 'Em Andamento',
            'feito': 'Feito',
            'revisado': 'Revisado',
            'entregue': 'Entregue',
            'upload_feito': 'Upload Feito'
        };
        return labels[status] || status;
    }

    isValidDate(dateString) {
        const date = new Date(dateString);
        return date instanceof Date && !isNaN(date);
    }

    generateDelayReport(delayedTexts) {
        const hoje = new Date().toLocaleDateString('pt-BR');
        let report = `RELATÓRIO DE ATRASOS - ${hoje}\n\n`;
        
        report += `RESUMO:\n`;
        report += `- Textos Atrasados: ${delayedTexts.overdue.length}\n`;
        report += `- Textos Urgentes: ${delayedTexts.urgent.length}\n`;
        report += `- Próximos Prazos: ${delayedTexts.upcoming.length}\n\n`;
        
        // Adicionar detalhes de cada categoria
        ['overdue', 'urgent', 'upcoming'].forEach(category => {
            const categoryName = category === 'overdue' ? 'ATRASADOS' : 
                               category === 'urgent' ? 'URGENTES' : 'PRÓXIMOS';
            report += `${categoryName}:\n`;
            
            delayedTexts[category].forEach(texto => {
                const cliente = clientes.find(c => c.id === texto.clienteId);
                const projeto = projetos.find(p => p.id === texto.projetoId);
                report += `- ${texto.titulo} (${cliente?.nome || 'N/A'} - ${projeto?.nome || 'N/A'}) - Prazo: ${texto.prazo}\n`;
            });
            report += '\n';
        });
        
        return report;
    }

    downloadReport(content, filename) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    saveData() {
        localStorage.setItem('textos', JSON.stringify(textos));
    }

    refreshDelaysPage() {
        if (document.getElementById('view').innerHTML.includes('delays-page')) {
            document.getElementById('view').innerHTML = this.renderDelaysPage();
        }
    }

    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
}

// Instância global
const delayManager = new DelayManager();


// Funcionalidades de edição de projetos

// Função para editar projeto
const editProjeto = (projetoId) => {
    const projeto = projetos.find(p => p.id === projetoId);
    if (!projeto) {
        showMessage('Erro', 'Projeto não encontrado!');
        return;
    }

    // Preencher o modal com os dados do projeto
    document.getElementById('projetoId').value = projeto.id;
    document.getElementById('projetoNome').value = projeto.nome;
    document.getElementById('projetoDescricao').value = projeto.descricao;
    document.getElementById('projetoCliente').value = projeto.clienteId;
    document.getElementById('projetoDataInicio').value = projeto.dataInicio;
    document.getElementById('projetoDataFim').value = projeto.dataFim;
    document.getElementById('projetoStatus').value = projeto.status;

    // Alterar o título do modal
    document.getElementById('modalProjetoTitle').innerText = 'Editar Projeto';
    
    // Abrir o modal
    openModal('modalProjeto');
};

// Função para salvar projeto (nova ou editada)
const saveProjeto = () => {
    const projetoId = document.getElementById('projetoId').value;
    const nome = document.getElementById('projetoNome').value.trim();
    const descricao = document.getElementById('projetoDescricao').value.trim();
    const clienteId = document.getElementById('projetoCliente').value;
    const dataInicio = document.getElementById('projetoDataInicio').value;
    const dataFim = document.getElementById('projetoDataFim').value;
    const status = document.getElementById('projetoStatus').value;

    // Validações
    if (!nome) {
        showMessage('Erro', 'Nome do projeto é obrigatório!');
        return;
    }

    if (!clienteId) {
        showMessage('Erro', 'Cliente é obrigatório!');
        return;
    }

    if (!dataInicio) {
        showMessage('Erro', 'Data de início é obrigatória!');
        return;
    }

    if (!dataFim) {
        showMessage('Erro', 'Data de fim é obrigatória!');
        return;
    }

    if (new Date(dataInicio) > new Date(dataFim)) {
        showMessage('Erro', 'Data de início não pode ser posterior à data de fim!');
        return;
    }

    const projetoData = {
        nome,
        descricao,
        clienteId,
        dataInicio,
        dataFim,
        status,
        resumo: projetoId ? projetos.find(p => p.id === projetoId)?.resumo || '' : '',
        observacoes: projetoId ? projetos.find(p => p.id === projetoId)?.observacoes || '' : ''
    };

    if (projetoId) {
        // Editar projeto existente
        dataManager.updateProjeto(projetoId, projetoData);
        showMessage('Sucesso', 'Projeto atualizado com sucesso!');
    } else {
        // Criar novo projeto
        dataManager.addProjeto(projetoData);
        showMessage('Sucesso', 'Projeto criado com sucesso!');
    }

    // Fechar modal e limpar formulário
    closeModal('modalProjeto');
    clearProjetoForm();
    
    // Atualizar a view atual
    views.projetos();
};

// Função para limpar o formulário de projeto
const clearProjetoForm = () => {
    document.getElementById('projetoId').value = '';
    document.getElementById('projetoNome').value = '';
    document.getElementById('projetoDescricao').value = '';
    document.getElementById('projetoCliente').value = '';
    document.getElementById('projetoDataInicio').value = '';
    document.getElementById('projetoDataFim').value = '';
    document.getElementById('projetoStatus').value = 'ativo';
    document.getElementById('modalProjetoTitle').innerText = 'Novo Projeto';
};

// Função para deletar projeto
const deleteProjeto = (projetoId) => {
    const projeto = projetos.find(p => p.id === projetoId);
    if (!projeto) {
        showMessage('Erro', 'Projeto não encontrado!');
        return;
    }

    showConfirm(
        'Confirmar Exclusão',
        `Tem certeza que deseja excluir o projeto "${projeto.nome}"? Esta ação não pode ser desfeita.`,
        () => {
            // Verificar se há textos associados ao projeto
            const textosAssociados = textos.filter(t => t.projetoId === projetoId);
            if (textosAssociados.length > 0) {
                showMessage('Erro', `Não é possível excluir o projeto pois há ${textosAssociados.length} texto(s) associado(s) a ele. Remova os textos primeiro.`);
                return;
            }

            // Remover documentos associados
            const documentosAssociados = documentos.filter(d => d.projetoId === projetoId);
            documentosAssociados.forEach(doc => {
                dataManager.removeDocumento(doc.id);
            });

            // Remover o projeto
            dataManager.removeProjeto(projetoId);
            showMessage('Sucesso', 'Projeto excluído com sucesso!');
            
            // Atualizar a view
            views.projetos();
        }
    );
};

// Função para preparar novo projeto
const newProjeto = () => {
    clearProjetoForm();
    openModal('modalProjeto');
};

// Função para popular o select de clientes no modal
const populateClienteSelect = () => {
    const select = document.getElementById('projetoCliente');
    if (!select) return;

    select.innerHTML = '<option value="">Selecione um cliente</option>';
    clientes.forEach(cliente => {
        const option = document.createElement('option');
        option.value = cliente.id;
        option.textContent = cliente.nome;
        select.appendChild(option);
    });
};

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    // Configurar evento do botão salvar no modal
    const btnSaveProjeto = document.getElementById('btnSaveProjeto');
    if (btnSaveProjeto) {
        btnSaveProjeto.onclick = saveProjeto;
    }

    // Popular select de clientes sempre que o modal for aberto
    const modalProjeto = document.getElementById('modalProjeto');
    if (modalProjeto) {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                    if (modalProjeto.classList.contains('is-visible')) {
                        populateClienteSelect();
                    }
                }
            });
        });
        observer.observe(modalProjeto, { attributes: true });
    }
});


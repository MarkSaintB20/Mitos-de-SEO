// Funcionalidades para exibir tarefas atrasadas no dashboard

// Função para calcular tarefas atrasadas
const getDelayedTasks = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return textos.filter(texto => {
        if (!texto.prazo) return false;
        
        const prazoDate = new Date(texto.prazo);
        prazoDate.setHours(0, 0, 0, 0);
        
        // Considera atrasado se o prazo já passou e não está entregue
        return prazoDate < today && !['entregue', 'upload_feito'].includes(texto.status);
    });
};

// Função para calcular tarefas urgentes (próximas 3 dias)
const getUrgentTasks = () => {
    const today = new Date();
    const urgentDate = new Date();
    urgentDate.setDate(today.getDate() + 3);
    
    today.setHours(0, 0, 0, 0);
    urgentDate.setHours(23, 59, 59, 999);
    
    return textos.filter(texto => {
        if (!texto.prazo) return false;
        
        const prazoDate = new Date(texto.prazo);
        
        // Considera urgente se está dentro dos próximos 3 dias e não está entregue
        return prazoDate >= today && prazoDate <= urgentDate && !['entregue', 'upload_feito'].includes(texto.status);
    });
};

// Função para renderizar widget de tarefas atrasadas
const renderDelayedTasksWidget = () => {
    const delayedTasks = getDelayedTasks();
    const urgentTasks = getUrgentTasks();
    
    return `
        <div class="view-section mt-4">
            <h2>⚠️ Alertas de Prazos</h2>
            <div class="delays-alerts">
                <div class="delay-alert ${delayedTasks.length > 0 ? 'alert-danger' : 'alert-success'}">
                    <div class="alert-header">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3>Tarefas Atrasadas</h3>
                        <span class="alert-count">${delayedTasks.length}</span>
                    </div>
                    ${delayedTasks.length > 0 ? `
                        <div class="alert-content">
                            <div class="delayed-tasks-list">
                                ${delayedTasks.slice(0, 3).map(texto => {
                                    const cliente = clientes.find(c => c.id === texto.clienteId);
                                    const projeto = projetos.find(p => p.id === texto.projetoId);
                                    const diasAtraso = Math.floor((new Date() - new Date(texto.prazo)) / (1000 * 60 * 60 * 24));
                                    
                                    return `
                                        <div class="delayed-task-item">
                                            <div class="task-info">
                                                <h4>${texto.titulo}</h4>
                                                <p><strong>Cliente:</strong> ${cliente?.nome || 'N/A'}</p>
                                                <p><strong>Projeto:</strong> ${projeto?.nome || 'N/A'}</p>
                                                <p><strong>Prazo:</strong> ${new Date(texto.prazo).toLocaleDateString('pt-BR')}</p>
                                            </div>
                                            <div class="task-delay">
                                                <span class="delay-badge">${diasAtraso} dia${diasAtraso > 1 ? 's' : ''} atrasado${diasAtraso > 1 ? 's' : ''}</span>
                                            </div>
                                        </div>
                                    `;
                                }).join('')}
                                ${delayedTasks.length > 3 ? `
                                    <div class="more-tasks">
                                        <button class="btn btn-link" onclick="views.atrasos()">
                                            Ver todas as ${delayedTasks.length} tarefas atrasadas
                                        </button>
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                    ` : `
                        <div class="alert-content">
                            <p class="success-message">🎉 Parabéns! Não há tarefas atrasadas no momento.</p>
                        </div>
                    `}
                </div>
                
                <div class="delay-alert ${urgentTasks.length > 0 ? 'alert-warning' : 'alert-info'}">
                    <div class="alert-header">
                        <i class="fas fa-clock"></i>
                        <h3>Tarefas Urgentes</h3>
                        <span class="alert-count">${urgentTasks.length}</span>
                    </div>
                    ${urgentTasks.length > 0 ? `
                        <div class="alert-content">
                            <div class="urgent-tasks-list">
                                ${urgentTasks.slice(0, 3).map(texto => {
                                    const cliente = clientes.find(c => c.id === texto.clienteId);
                                    const projeto = projetos.find(p => p.id === texto.projetoId);
                                    const diasRestantes = Math.ceil((new Date(texto.prazo) - new Date()) / (1000 * 60 * 60 * 24));
                                    
                                    return `
                                        <div class="urgent-task-item">
                                            <div class="task-info">
                                                <h4>${texto.titulo}</h4>
                                                <p><strong>Cliente:</strong> ${cliente?.nome || 'N/A'}</p>
                                                <p><strong>Projeto:</strong> ${projeto?.nome || 'N/A'}</p>
                                                <p><strong>Prazo:</strong> ${new Date(texto.prazo).toLocaleDateString('pt-BR')}</p>
                                            </div>
                                            <div class="task-urgency">
                                                <span class="urgency-badge">${diasRestantes} dia${diasRestantes > 1 ? 's' : ''} restante${diasRestantes > 1 ? 's' : ''}</span>
                                            </div>
                                        </div>
                                    `;
                                }).join('')}
                                ${urgentTasks.length > 3 ? `
                                    <div class="more-tasks">
                                        <button class="btn btn-link" onclick="views.atrasos()">
                                            Ver todas as ${urgentTasks.length} tarefas urgentes
                                        </button>
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                    ` : `
                        <div class="alert-content">
                            <p class="info-message">ℹ️ Não há tarefas com prazo urgente nos próximos 3 dias.</p>
                        </div>
                    `}
                </div>
            </div>
        </div>
    `;
};

// Função para obter estatísticas de atrasos para o dashboard
const getDelayStats = () => {
    const delayedTasks = getDelayedTasks();
    const urgentTasks = getUrgentTasks();
    
    return {
        atrasadas: delayedTasks.length,
        urgentes: urgentTasks.length,
        totalAlertas: delayedTasks.length + urgentTasks.length
    };
};


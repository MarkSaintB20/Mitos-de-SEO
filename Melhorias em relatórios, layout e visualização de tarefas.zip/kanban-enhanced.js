// Funcionalidades aprimoradas para o Kanban

let kanbanFilters = {
    cliente: '',
    projeto: ''
};

let kanbanViewMode = 'compact';

// Função para renderizar tarefas do Kanban com melhorias
const renderKanbanTasks = () => {
    const statusColumns = ['a_fazer', 'em_andamento', 'feito', 'revisado', 'entregue', 'upload_feito'];
    
    statusColumns.forEach(status => {
        const column = document.getElementById(`kanban-${status}`);
        if (!column) return;
        
        let filteredTextos = textos.filter(texto => texto.status === status);
        
        // Aplicar filtros
        if (kanbanFilters.cliente) {
            filteredTextos = filteredTextos.filter(texto => texto.clienteId === kanbanFilters.cliente);
        }
        
        if (kanbanFilters.projeto) {
            filteredTextos = filteredTextos.filter(texto => texto.projetoId === kanbanFilters.projeto);
        }
        
        // Atualizar contador no header
        const header = column.parentElement.querySelector('.kanban-column-header');
        if (header) {
            header.setAttribute('data-count', filteredTextos.length);
        }
        
        column.innerHTML = filteredTextos.map(texto => {
            const cliente = clientes.find(c => c.id === texto.clienteId);
            const projeto = projetos.find(p => p.id === texto.projetoId);
            const redator = redatores.find(r => r.id === texto.redatorId);
            
            // Calcular status do prazo
            let deadlineClass = '';
            let deadlineText = '';
            
            if (texto.prazo) {
                const prazoDate = new Date(texto.prazo);
                const today = new Date();
                const diffTime = prazoDate - today;
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                
                if (diffDays < 0) {
                    deadlineClass = 'overdue';
                    deadlineText = `${Math.abs(diffDays)} dias atrasado`;
                } else if (diffDays <= 3) {
                    deadlineClass = 'urgent';
                    deadlineText = `${diffDays} dias restantes`;
                } else {
                    deadlineText = prazoDate.toLocaleDateString('pt-BR');
                }
            }
            
            return `
                <div class="kanban-task" draggable="true" data-id="${texto.id}" data-status="${texto.status}">
                    <h4>${texto.titulo}</h4>
                    ${kanbanViewMode === 'expanded' ? `
                        <p><strong>Cliente:</strong> ${cliente?.nome || 'N/A'}</p>
                        <p><strong>Projeto:</strong> ${projeto?.nome || 'N/A'}</p>
                        <p><strong>Redator:</strong> ${redator?.nome || 'N/A'}</p>
                    ` : `
                        <p>${cliente?.nome || 'N/A'} • ${projeto?.nome || 'N/A'}</p>
                    `}
                    <div class="task-meta">
                        <span class="task-priority ${texto.prioridade || 'media'}">${(texto.prioridade || 'media').toUpperCase()}</span>
                        ${texto.prazo ? `<span class="task-deadline ${deadlineClass}">${deadlineText}</span>` : ''}
                    </div>
                </div>
            `;
        }).join('');
    });
};

// Função para filtrar tarefas do Kanban
const filterKanbanTasks = () => {
    const clienteFilter = document.getElementById('kanbanClienteFilter');
    const projetoFilter = document.getElementById('kanbanProjetoFilter');
    
    kanbanFilters.cliente = clienteFilter ? clienteFilter.value : '';
    kanbanFilters.projeto = projetoFilter ? projetoFilter.value : '';
    
    renderKanbanTasks();
};

// Função para alternar visualização do Kanban
const toggleKanbanView = (mode) => {
    kanbanViewMode = mode;
    
    const compactBtn = document.getElementById('compactViewBtn');
    const expandedBtn = document.getElementById('expandedViewBtn');
    const kanbanBoard = document.getElementById('kanbanBoard');
    
    if (mode === 'compact') {
        compactBtn.classList.remove('btn-outline-secondary');
        compactBtn.classList.add('btn-secondary');
        expandedBtn.classList.remove('btn-secondary');
        expandedBtn.classList.add('btn-outline-secondary');
        kanbanBoard.classList.add('compact-view');
        kanbanBoard.classList.remove('expanded-view');
    } else {
        expandedBtn.classList.remove('btn-outline-secondary');
        expandedBtn.classList.add('btn-secondary');
        compactBtn.classList.remove('btn-secondary');
        compactBtn.classList.add('btn-outline-secondary');
        kanbanBoard.classList.add('expanded-view');
        kanbanBoard.classList.remove('compact-view');
    }
    
    renderKanbanTasks();
};

// Função para inicializar drag and drop
const initKanbanDragDrop = () => {
    const tasks = document.querySelectorAll('.kanban-task');
    const columns = document.querySelectorAll('.kanban-tasks');
    
    tasks.forEach(task => {
        task.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', task.dataset.id);
            task.classList.add('dragging');
        });
        
        task.addEventListener('dragend', () => {
            task.classList.remove('dragging');
        });
    });
    
    columns.forEach(column => {
        column.addEventListener('dragover', (e) => {
            e.preventDefault();
            column.parentElement.classList.add('drag-over');
        });
        
        column.addEventListener('dragleave', () => {
            column.parentElement.classList.remove('drag-over');
        });
        
        column.addEventListener('drop', (e) => {
            e.preventDefault();
            column.parentElement.classList.remove('drag-over');
            
            const taskId = e.dataTransfer.getData('text/plain');
            const newStatus = column.id.replace('kanban-', '');
            
            // Atualizar status da tarefa
            const texto = textos.find(t => t.id === taskId);
            if (texto && texto.status !== newStatus) {
                texto.status = newStatus;
                dataManager.updateTexto(taskId, { status: newStatus });
                renderKanbanTasks();
                
                // Mostrar notificação
                showMessage('Sucesso', `Tarefa "${texto.titulo}" movida para "${getStatusLabel(newStatus)}"`);
            }
        });
    });
};

// Função para obter label do status
const getStatusLabel = (status) => {
    const labels = {
        'a_fazer': 'A Fazer',
        'em_andamento': 'Em Andamento',
        'feito': 'Feito',
        'revisado': 'Revisado',
        'entregue': 'Entregue',
        'upload_feito': 'Upload Feito'
    };
    return labels[status] || status;
};

// Função para adicionar estilos dinâmicos baseados no modo de visualização
const updateKanbanStyles = () => {
    const existingStyle = document.getElementById('kanban-dynamic-styles');
    if (existingStyle) {
        existingStyle.remove();
    }
    
    const style = document.createElement('style');
    style.id = 'kanban-dynamic-styles';
    
    if (kanbanViewMode === 'compact') {
        style.textContent = `
            .kanban-board.compact-view {
                grid-template-columns: repeat(6, minmax(180px, 1fr));
                gap: 0.5rem;
            }
            
            .kanban-board.compact-view .kanban-task {
                padding: 0.5rem;
                font-size: 0.8rem;
            }
            
            .kanban-board.compact-view .kanban-task h4 {
                font-size: 0.85rem;
                margin-bottom: 0.25rem;
            }
            
            .kanban-board.compact-view .kanban-task p {
                font-size: 0.75rem;
                margin: 0.125rem 0;
            }
            
            .kanban-board.compact-view .task-meta {
                margin-top: 0.25rem;
                padding-top: 0.25rem;
            }
            
            .kanban-board.compact-view .task-priority,
            .kanban-board.compact-view .task-deadline {
                font-size: 0.7rem;
                padding: 0.1rem 0.3rem;
            }
        `;
    } else {
        style.textContent = `
            .kanban-board.expanded-view {
                grid-template-columns: repeat(3, 1fr);
                grid-template-rows: repeat(2, 1fr);
                gap: 1rem;
            }
            
            .kanban-board.expanded-view .kanban-column {
                min-width: auto;
                max-width: none;
            }
            
            .kanban-board.expanded-view .kanban-task {
                padding: 1rem;
                font-size: 0.9rem;
            }
            
            .kanban-board.expanded-view .kanban-task h4 {
                font-size: 1rem;
                margin-bottom: 0.5rem;
            }
            
            .kanban-board.expanded-view .kanban-task p {
                font-size: 0.85rem;
                margin: 0.25rem 0;
            }
        `;
    }
    
    document.head.appendChild(style);
};

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    // Configurar modo compacto por padrão
    kanbanViewMode = 'compact';
    updateKanbanStyles();
});


// Dados simulados (agora usando dataManager)
let textos = [];
let clientes = [];
let redatores = [];
let guestPosts = [];
let projetos = [];
let documentos = [];

// Inicializar dados do dataManager
const initializeDataFromManager = () => {
    if (window.dataManager) {
        textos = dataManager.textos;
        clientes = dataManager.clientes;
        redatores = dataManager.redatores;
        guestPosts = dataManager.guestPosts;
        projetos = dataManager.projetos;
        documentos = dataManager.documentos;
    }
};

// Funções auxiliares para gerenciar modais
const openModal = (modalId) => {
    document.getElementById(modalId).classList.add('is-visible');
};

const closeModal = (modalId) => {
    document.getElementById(modalId).classList.remove('is-visible');
};

// Função para exibir mensagens
const showMessage = (title, message) => {
    document.getElementById('messageModalTitle').innerText = title;
    document.getElementById('messageModalContent').innerText = message;
    openModal('messageModal');
};

// Função para exibir confirmação
const showConfirm = (title, message, onConfirm) => {
    document.getElementById('confirmModalTitle').innerText = title;
    document.getElementById('confirmModalContent').innerText = message;
    openModal('confirmModal');

    document.getElementById('confirmAction').onclick = () => {
        onConfirm();
        closeModal('confirmModal');
    };
};

// Gerenciamento de rotas/views
const views = {
    dashboard: () => {
        document.getElementById('pageTitle').innerText = 'Dashboard Geral';
        document.getElementById('view').innerHTML = `
            <div class="view-section">
                <h2>Visão Geral</h2>
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <h3>Textos Ativos</h3>
                        <p class="value">${textos.filter(t => !['entregue', 'upload_feito'].includes(t.status)).length}</p>
                        <p class="description">Textos em produção ou aguardando entrega.</p>
                    </div>
                    <div class="dashboard-card">
                        <h3>Projetos Ativos</h3>
                        <p class="value">${projetos.filter(p => p.status === 'ativo').length}</p>
                        <p class="description">Projetos em andamento.</p>
                    </div>
                    <div class="dashboard-card">
                        <h3>Clientes Ativos</h3>
                        <p class="value">${clientes.length}</p>
                        <p class="description">Total de clientes cadastrados.</p>
                    </div>
                    <div class="dashboard-card">
                        <h3>Guest Posts Publicados</h3>
                        <p class="value">${guestPosts.filter(gp => gp.status === 'publicado').length}</p>
                        <p class="description">Artigos publicados em outros sites.</p>
                    </div>
                </div>
            </div>
            <div class="view-section mt-4">
                <h2>Dashboards por Cliente</h2>
                <div class="client-dashboards">
                    ${clientes.map(cliente => {
                        const stats = dataManager.getClienteStats(cliente.id);
                        return `
                            <div class="client-dashboard-card" onclick="showClientDashboard('${cliente.id}')">
                                <h3>${cliente.nome}</h3>
                                <div class="client-stats">
                                    <div class="stat">
                                        <span class="stat-value">${stats.totalTextos}</span>
                                        <span class="stat-label">Total Textos</span>
                                    </div>
                                    <div class="stat">
                                        <span class="stat-value">${stats.textosAtivos}</span>
                                        <span class="stat-label">Em Andamento</span>
                                    </div>
                                    <div class="stat">
                                        <span class="stat-value">${stats.totalProjetos}</span>
                                        <span class="stat-label">Projetos</span>
                                    </div>
                                </div>
                                <button class="btn btn-primary btn-sm">Ver Dashboard</button>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
            ${renderDelayedTasksWidget()}
            <div class="view-section mt-4">
                <h2>Progresso Mensal</h2>
                <canvas id="monthlyProgressChart"></canvas>
            </div>
            <div class="view-section mt-4">
                <h2>Métricas Detalhadas</h2>
                <div class="charts-grid">
                    <div class="chart-card">
                        <canvas id="statusDistributionChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <canvas id="clientTextChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <canvas id="redatorProductivityChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <canvas id="monthlyPerformanceChart"></canvas>
                    </div>
                </div>
            </div>
        `;
        renderMonthlyProgressChart();
        renderAdditionalCharts();
    },
    kanban: () => {
        document.getElementById('pageTitle').innerText = 'Kanban';
        document.getElementById('view').innerHTML = `
            <div class="view-section">
                <h2>Quadro de Tarefas</h2>
                <div class="kanban-controls">
                    <div class="kanban-filters">
                        <select id="kanbanClienteFilter" onchange="filterKanbanTasks()">
                            <option value="">Todos os Clientes</option>
                            ${clientes.map(c => `<option value="${c.id}">${c.nome}</option>`).join('')}
                        </select>
                        <select id="kanbanProjetoFilter" onchange="filterKanbanTasks()">
                            <option value="">Todos os Projetos</option>
                            ${projetos.map(p => `<option value="${p.id}">${p.nome}</option>`).join('')}
                        </select>
                    </div>
                    <div class="kanban-view-toggle">
                        <button class="btn btn-sm btn-secondary" onclick="toggleKanbanView('compact')" id="compactViewBtn">
                            <i class="fas fa-compress-alt"></i> Compacto
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" onclick="toggleKanbanView('expanded')" id="expandedViewBtn">
                            <i class="fas fa-expand-alt"></i> Expandido
                        </button>
                    </div>
                </div>
                <div class="kanban-board" id="kanbanBoard">
                    <div class="kanban-column">
                        <div class="kanban-column-header" data-count="0">A Fazer</div>
                        <div class="kanban-tasks" id="kanban-a_fazer"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-column-header" data-count="0">Em Andamento</div>
                        <div class="kanban-tasks" id="kanban-em_andamento"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-column-header" data-count="0">Feito</div>
                        <div class="kanban-tasks" id="kanban-feito"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-column-header" data-count="0">Revisado</div>
                        <div class="kanban-tasks" id="kanban-revisado"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-column-header" data-count="0">Entregue</div>
                        <div class="kanban-tasks" id="kanban-entregue"></div>
                    </div>
                    <div class="kanban-column">
                        <div class="kanban-column-header" data-count="0">Upload Feito</div>
                        <div class="kanban-tasks" id="kanban-upload_feito"></div>
                    </div>
                </div>
            </div>
        `;
        renderKanbanTasks();
        initKanbanDragDrop();
    },
    clientes: () => {
        document.getElementById('pageTitle').innerText = 'Clientes';
        document.getElementById('view').innerHTML = `
            <div class="view-section">
                <h2>Gerenciar Clientes</h2>
                <button class="btn btn-primary mb-3" id="btnAddCliente"><i class="fas fa-plus"></i> Novo Cliente</button>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Contato</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="clientesTableBody"></tbody>
                </table>
            </div>
        `;
        renderClientesTable();
        document.getElementById('btnAddCliente').onclick = () => openModal('modalCliente');
    },
    projetos: () => {
        document.getElementById('pageTitle').innerText = 'Projetos';
        document.getElementById('view').innerHTML = `
            <div class="view-section">
                <h2>Gerenciar Projetos</h2>
                <button class="btn btn-primary mb-3" id="btnAddProjeto"><i class="fas fa-plus"></i> Novo Projeto</button>
                <div class="projects-grid">
                    ${projetos.map(projeto => {
                        const cliente = clientes.find(c => c.id === projeto.clienteId);
                        const textosCount = textos.filter(t => t.projetoId === projeto.id).length;
                        const documentosCount = documentos.filter(d => d.projetoId === projeto.id).length;
                        return `
                            <div class="project-card">
                                <div class="project-header">
                                    <h3>${projeto.nome}</h3>
                                    <span class="project-status ${projeto.status}">${projeto.status.toUpperCase()}</span>
                                </div>
                                <div class="project-info">
                                    <p><strong>Cliente:</strong> ${cliente?.nome || 'N/A'}</p>
                                    <p><strong>Descrição:</strong> ${projeto.descricao}</p>
                                    <p><strong>Período:</strong> ${projeto.dataInicio} até ${projeto.dataFim}</p>
                                </div>
                                <div class="project-stats">
                                    <div class="stat">
                                        <span class="stat-value">${textosCount}</span>
                                        <span class="stat-label">Textos</span>
                                    </div>
                                    <div class="stat">
                                        <span class="stat-value">${documentosCount}</span>
                                        <span class="stat-label">Documentos</span>
                                    </div>
                                </div>
                                <div class="project-actions">
                                    <button class="btn btn-sm btn-secondary" onclick="editProjeto('${projeto.id}')">
                                        <i class="fas fa-edit"></i> Editar
                                    </button>
                                    <button class="btn btn-sm btn-primary" onclick="showProjectDetails('${projeto.id}')">
                                        <i class="fas fa-eye"></i> Detalhes
                                    </button>
                                    <button class="btn btn-sm btn-danger" onclick="deleteProjeto('${projeto.id}')">
                                        <i class="fas fa-trash"></i> Excluir
                                    </button>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
        document.getElementById('btnAddProjeto').onclick = () => newProjeto();
    },
    redatores: () => {
        document.getElementById('pageTitle').innerText = 'Redatores';
        document.getElementById('view').innerHTML = `
            <div class="view-section">
                <h2>Gerenciar Redatores</h2>
                <button class="btn btn-primary mb-3" id="btnAddRedator"><i class="fas fa-plus"></i> Novo Redator</button>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Especialidade</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="redatoresTableBody"></tbody>
                </table>
            </div>
        `;
        renderRedatoresTable();
        document.getElementById('btnAddRedator').onclick = () => openModal('modalRedator');
    },
    guestposts: () => {
        document.getElementById('pageTitle').innerText = 'Guest Posts';
        document.getElementById('view').innerHTML = `
            <div class="view-section">
                <h2>Gerenciar Guest Posts</h2>
                <button class="btn btn-primary mb-3" id="btnAddGuestPost"><i class="fas fa-plus"></i> Novo Guest Post</button>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Cliente</th>
                            <th>Status</th>
                            <th>Data Publicação</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="guestPostsTableBody"></tbody>
                </table>
            </div>
        `;
        renderGuestPostsTable();
        document.getElementById('btnAddGuestPost').onclick = () => openModal('modalGuestPost');
    },
    relatorios: () => {
        document.getElementById('pageTitle').innerText = 'Relatórios';
        document.getElementById('view').innerHTML = `
            <div class="report-section">
                <h2>Relatórios de Conteúdo</h2>
                <div class="report-filters">
                    <div class="form-group">
                        <label for="reportClienteFilter">Cliente</label>
                        <select id="reportClienteFilter"></select>
                    </div>
                    <div class="form-group">
                        <label for="reportRedatorFilter">Redator</label>
                        <select id="reportRedatorFilter"></select>
                    </div>
                    <div class="form-group">
                        <label for="reportPeriodoFilter">Período</label>
                        <select id="reportPeriodoFilter">
                            <option value="all">Todo o Período</option>
                            <option value="month">Último Mês</option>
                            <option value="quarter">Último Trimestre</option>
                            <option value="year">Último Ano</option>
                        </select>
                    </div>
                    <button class="btn btn-primary" id="btnGenerateReport">Gerar Relatório</button>
                </div>
                <div class="report-charts">
                    <div class="chart-card">
                        <h3>Textos por Status</h3>
                        <canvas id="statusChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <h3>Textos por Cliente</h3>
                        <canvas id="clientChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <h3>Textos por Redator</h3>
                        <canvas id="redactorChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <h3>Produtividade Mensal</h3>
                        <canvas id="productivityChart"></canvas>
                    </div>
                </div>
            </div>
        `;
        populateReportFilters();
        document.getElementById('btnGenerateReport').onclick = generateReports;
        generateReports(); // Gerar relatórios iniciais
    },
    calendario: () => {
        document.getElementById('pageTitle').innerText = 'Calendário Mensal';
        document.getElementById('view').innerHTML = calendarManager.renderCalendarView();
        calendarManager.initializeEventListeners();
        calendarManager.renderMonthlyTasksList();
    },
    config: () => {
        document.getElementById('pageTitle').innerText = 'Configurações';
        document.getElementById('view').innerHTML = `
            <div class="settings-section">
                <h2>Configurações do Sistema</h2>
                <div class="settings-group">
                    <h3>Geral</h3>
                    <div class="settings-item">
                        <label for="appName">Nome da Aplicação</label>
                        <input type="text" id="appName" value="B20 — Gestor de Conteúdo">
                    </div>
                    <div class="settings-item">
                        <label for="itemsPerPage">Itens por Página (Tabelas)</label>
                        <input type="number" id="itemsPerPage" value="10" min="5" max="50">
                    </div>
                </div>
                <div class="settings-group">
                    <h3>Notificações</h3>
                    <div class="settings-item">
                        <label for="emailNotifications">Receber notificações por e-mail</label>
                        <input type="checkbox" id="emailNotifications" checked>
                    </div>
                    <div class="settings-item">
                        <label for="deadlineReminders">Lembretes de prazo</label>
                        <input type="checkbox" id="deadlineReminders" checked>
                    </div>
                </div>
                <div class="settings-group">
                    <h3>Dados</h3>
                    <div class="settings-item">
                        <label>Exportar todos os dados</label>
                        <button class="btn btn-secondary" id="btnExportAllData"><i class="fas fa-download"></i> Exportar</button>
                    </div>
                    <div class="settings-item">
                        <label>Importar dados (sobrescreverá os existentes)</label>
                        <label class="btn btn-secondary" for="importAllDataFile"><i class="fas fa-upload"></i> Importar</label>
                        <input id="importAllDataFile" class="sr-only" type="file" accept="application/json">
                    </div>
                    <div class="settings-item">
                        <label>Resetar todos os dados (ação irreversível)</label>
                        <button class="btn btn-danger" id="btnResetAllData"><i class="fas fa-trash"></i> Resetar</button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="btnSaveSettings">Salvar Configurações</button>
                </div>
            </div>
        `;
        document.getElementById('btnExportAllData').onclick = exportAllData;
        document.getElementById('importAllDataFile').onchange = importAllData;
        document.getElementById('btnResetAllData').onclick = () => showConfirm('Resetar Dados', 'Tem certeza que deseja resetar todos os dados? Esta ação é irreversível.', resetAllData);
        document.getElementById('btnSaveSettings').onclick = saveSettings;
    },
    atrasos: () => {
        document.getElementById('pageTitle').innerText = 'Gestão de Atrasos';
        document.getElementById('view').innerHTML = delayManager.renderDelaysPage();
    }
};

// Função para renderizar o gráfico de progresso mensal (Dashboard)
let monthlyProgressChartInstance = null;
const renderMonthlyProgressChart = () => {
    const ctx = document.getElementById('monthlyProgressChart').getContext('2d');
    if (monthlyProgressChartInstance) {
        monthlyProgressChartInstance.destroy();
    }
    monthlyProgressChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
            datasets: [{
                label: 'Textos Entregues',
                data: [12, 19, 3, 5, 2, 3, 7, 10, 15, 8, 11, 6], // Dados de exemplo
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
};

// Funções para renderizar tabelas
const renderClientesTable = () => {
    const tbody = document.getElementById('clientesTableBody');
    tbody.innerHTML = '';
    clientes.forEach(cliente => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${cliente.nome}</td>
            <td>${cliente.contato || 'N/A'}</td>
            <td class="actions">
                <button onclick="editCliente('${cliente.id}')"><i class="fas fa-edit"></i></button>
                <button onclick="deleteCliente('${cliente.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
};

const renderRedatoresTable = () => {
    const tbody = document.getElementById('redatoresTableBody');
    tbody.innerHTML = '';
    redatores.forEach(redator => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${redator.nome}</td>
            <td>${redator.especialidade || 'N/A'}</td>
            <td class="actions">
                <button onclick="editRedator('${redator.id}')"><i class="fas fa-edit"></i></button>
                <button onclick="deleteRedator('${redator.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
};

const renderGuestPostsTable = () => {
    const tbody = document.getElementById('guestPostsTableBody');
    tbody.innerHTML = '';
    guestPosts.forEach(gp => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${gp.titulo}</td>
            <td>${clientes.find(c => c.id === gp.clienteId)?.nome || 'N/A'}</td>
            <td><span class="badge badge-${gp.status}">${gp.status.replace('_', ' ')}</span></td>
            <td>${gp.dataPublicacao || 'N/A'}</td>
            <td class="actions">
                <button onclick="editGuestPost('${gp.id}')"><i class="fas fa-edit"></i></button>
                <button onclick="deleteGuestPost('${gp.id}')"><i class="fas fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
};

// Funções de CRUD para dados simulados (apenas frontend)
const saveTexto = (event) => {
    event.preventDefault();
    const id = document.getElementById('textoId').value;
    const texto = {
        id: id || Date.now().toString(),
        titulo: document.getElementById('textoTitulo').value,
        clienteId: document.getElementById('textoCliente').value,
        redatorId: document.getElementById('textoRedator').value,
        prazo: document.getElementById('textoPrazo').value,
        status: document.getElementById('textoStatus').value,
        uploadBy: document.getElementById('textoUploadBy').value,
        uploadDone: document.getElementById('textoUploadDone').value === 'true',
        onDemand: document.getElementById('textoOnDemand').value === 'true',
        notas: document.getElementById('textoNotas').value
    };

    if (id) {
        const index = textos.findIndex(t => t.id === id);
        if (index !== -1) textos[index] = texto;
    } else {
        textos.push(texto);
    }
    closeModal('modalTexto');
    views[currentView](); // Recarrega a view atual
    showMessage('Sucesso', 'Texto salvo com sucesso!');
};

const editTexto = (id) => {
    const texto = textos.find(t => t.id === id);
    if (texto) {
        document.getElementById('modalTextoTitle').innerText = 'Editar Texto';
        document.getElementById('textoId').value = texto.id;
        document.getElementById('textoTitulo').value = texto.titulo;
        document.getElementById('textoCliente').value = texto.clienteId;
        document.getElementById('textoRedator').value = texto.redatorId;
        document.getElementById('textoPrazo').value = texto.prazo;
        document.getElementById('textoStatus').value = texto.status;
        document.getElementById('textoUploadBy').value = texto.uploadBy;
        document.getElementById('textoUploadDone').value = texto.uploadDone.toString();
        document.getElementById('textoOnDemand').value = texto.onDemand.toString();
        document.getElementById('textoNotas').value = texto.notas;
        openModal('modalTexto');
    }
};

const deleteTexto = (id) => {
    showConfirm('Confirmar Exclusão', 'Tem certeza que deseja excluir este texto?', () => {
        textos = textos.filter(t => t.id !== id);
        views[currentView]();
        showMessage('Sucesso', 'Texto excluído com sucesso!');
    });
};

const saveCliente = (event) => {
    event.preventDefault();
    const id = document.getElementById('clienteId').value;
    const cliente = {
        id: id || Date.now().toString(),
        nome: document.getElementById('clienteNome').value,
        contato: document.getElementById('clienteContato').value
    };

    if (id) {
        const index = clientes.findIndex(c => c.id === id);
        if (index !== -1) clientes[index] = cliente;
    } else {
        clientes.push(cliente);
    }
    closeModal('modalCliente');
    views[currentView]();
    showMessage('Sucesso', 'Cliente salvo com sucesso!');
};

const editCliente = (id) => {
    const cliente = clientes.find(c => c.id === id);
    if (cliente) {
        document.getElementById('modalClienteTitle').innerText = 'Editar Cliente';
        document.getElementById('clienteId').value = cliente.id;
        document.getElementById('clienteNome').value = cliente.nome;
        document.getElementById('clienteContato').value = cliente.contato;
        openModal('modalCliente');
    }
};

const deleteCliente = (id) => {
    showConfirm('Confirmar Exclusão', 'Tem certeza que deseja excluir este cliente?', () => {
        clientes = clientes.filter(c => c.id !== id);
        views[currentView]();
        showMessage('Sucesso', 'Cliente excluído com sucesso!');
    });
};

const saveRedator = (event) => {
    event.preventDefault();
    const id = document.getElementById('redatorId').value;
    const redator = {
        id: id || Date.now().toString(),
        nome: document.getElementById('redatorNome').value,
        especialidade: document.getElementById('redatorEspecialidade').value
    };

    if (id) {
        const index = redatores.findIndex(r => r.id === id);
        if (index !== -1) redatores[index] = redator;
    } else {
        redatores.push(redator);
    }
    closeModal('modalRedator');
    views[currentView]();
    showMessage('Sucesso', 'Redator salvo com sucesso!');
};

const editRedator = (id) => {
    const redator = redatores.find(r => r.id === id);
    if (redator) {
        document.getElementById('modalRedatorTitle').innerText = 'Editar Redator';
        document.getElementById('redatorId').value = redator.id;
        document.getElementById('redatorNome').value = redator.nome;
        document.getElementById('redatorEspecialidade').value = redator.especialidade;
        openModal('modalRedator');
    }
};

const deleteRedator = (id) => {
    showConfirm('Confirmar Exclusão', 'Tem certeza que deseja excluir este redator?', () => {
        redatores = redatores.filter(r => r.id !== id);
        views[currentView]();
        showMessage('Sucesso', 'Redator excluído com sucesso!');
    });
};

const saveGuestPost = (event) => {
    event.preventDefault();
    const id = document.getElementById('guestPostId').value;
    const guestPost = {
        id: id || Date.now().toString(),
        titulo: document.getElementById('guestPostTitulo').value,
        clienteId: document.getElementById('guestPostCliente').value,
        url: document.getElementById('guestPostUrl').value,
        dataPublicacao: document.getElementById('guestPostDataPublicacao').value,
        status: document.getElementById('guestPostStatus').value,
        domainAuthority: document.getElementById('guestPostDomainAuthority').value,
        backlink: document.getElementById('guestPostBacklink').value,
        notas: document.getElementById('guestPostNotas').value
    };

    if (id) {
        const index = guestPosts.findIndex(gp => gp.id === id);
        if (index !== -1) guestPosts[index] = guestPost;
    } else {
        guestPosts.push(guestPost);
    }
    closeModal('modalGuestPost');
    views[currentView]();
    showMessage('Sucesso', 'Guest Post salvo com sucesso!');
};

const editGuestPost = (id) => {
    const gp = guestPosts.find(gp => gp.id === id);
    if (gp) {
        document.getElementById('modalGuestPostTitle').innerText = 'Editar Guest Post';
        document.getElementById('guestPostId').value = gp.id;
        document.getElementById('guestPostTitulo').value = gp.titulo;
        document.getElementById('guestPostCliente').value = gp.clienteId;
        document.getElementById('guestPostUrl').value = gp.url;
        document.getElementById('guestPostDataPublicacao').value = gp.dataPublicacao;
        document.getElementById('guestPostStatus').value = gp.status;
        document.getElementById('guestPostDomainAuthority').value = gp.domainAuthority;
        document.getElementById('guestPostBacklink').value = gp.backlink;
        document.getElementById('guestPostNotas').value = gp.notas;
        openModal('modalGuestPost');
    }
};

const deleteGuestPost = (id) => {
    showConfirm('Confirmar Exclusão', 'Tem certeza que deseja excluir este Guest Post?', () => {
        guestPosts = guestPosts.filter(gp => gp.id !== id);
        views[currentView]();
        showMessage('Sucesso', 'Guest Post excluído com sucesso!');
    });
};

// Funções para Relatórios
let statusChartInstance, clientChartInstance, redactorChartInstance, productivityChartInstance;

const populateReportFilters = () => {
    const clienteFilter = document.getElementById('reportClienteFilter');
    const redatorFilter = document.getElementById('reportRedatorFilter');

    clienteFilter.innerHTML = '<option value="all">Todos os Clientes</option>';
    clientes.forEach(c => {
        const option = document.createElement('option');
        option.value = c.id;
        option.innerText = c.nome;
        clienteFilter.appendChild(option);
    });

    redatorFilter.innerHTML = '<option value="all">Todos os Redatores</option>';
    redatores.forEach(r => {
        const option = document.createElement('option');
        option.value = r.id;
        option.innerText = r.nome;
        redatorFilter.appendChild(option);
    });
};

const filterDataForReports = () => {
    const selectedCliente = document.getElementById('reportClienteFilter').value;
    const selectedRedator = document.getElementById('reportRedatorFilter').value;
    const selectedPeriodo = document.getElementById('reportPeriodoFilter').value;

    let filteredTextos = [...textos];

    if (selectedCliente !== 'all') {
        filteredTextos = filteredTextos.filter(t => t.clienteId === selectedCliente);
    }
    if (selectedRedator !== 'all') {
        filteredTextos = filteredTextos.filter(t => t.redatorId === selectedRedator);
    }

    const now = new Date();
    if (selectedPeriodo === 'month') {
        const oneMonthAgo = new Date(now.setMonth(now.getMonth() - 1));
        filteredTextos = filteredTextos.filter(t => new Date(t.prazo) >= oneMonthAgo);
    } else if (selectedPeriodo === 'quarter') {
        const threeMonthsAgo = new Date(now.setMonth(now.getMonth() - 3));
        filteredTextos = filteredTextos.filter(t => new Date(t.prazo) >= threeMonthsAgo);
    } else if (selectedPeriodo === 'year') {
        const oneYearAgo = new Date(now.setFullYear(now.getFullYear() - 1));
        filteredTextos = filteredTextos.filter(t => new Date(t.prazo) >= oneYearAgo);
    }

    return filteredTextos;
};

const generateReports = () => {
    const filteredTextos = filterDataForReports();

    // Chart 1: Textos por Status
    const statusCounts = {};
    filteredTextos.forEach(t => {
        statusCounts[t.status] = (statusCounts[t.status] || 0) + 1;
    });
    const statusLabels = Object.keys(statusCounts).map(s => s.replace('_', ' ').toUpperCase());
    const statusData = Object.values(statusCounts);
    renderChart('statusChart', 'pie', statusLabels, statusData, 'Textos por Status', statusChartInstance);

    // Chart 2: Textos por Cliente
    const clientCounts = {};
    filteredTextos.forEach(t => {
        const clientName = clientes.find(c => c.id === t.clienteId)?.nome || 'Desconhecido';
        clientCounts[clientName] = (clientCounts[clientName] || 0) + 1;
    });
    const clientLabels = Object.keys(clientCounts);
    const clientData = Object.values(clientCounts);
    renderChart('clientChart', 'bar', clientLabels, clientData, 'Textos por Cliente', clientChartInstance);

    // Chart 3: Textos por Redator
    const redactorCounts = {};
    filteredTextos.forEach(t => {
        const redactorName = redatores.find(r => r.id === t.redatorId)?.nome || 'Não Atribuído';
        redactorCounts[redactorName] = (redactorCounts[redactorName] || 0) + 1;
    });
    const redactorLabels = Object.keys(redactorCounts);
    const redactorData = Object.values(redactorCounts);
    renderChart('redactorChart', 'bar', redactorLabels, redactorData, 'Textos por Redator', redactorChartInstance);

    // Chart 4: Produtividade Mensal (textos entregues ao longo do tempo)
    const monthlyProductivity = {};
    filteredTextos.filter(t => t.status === 'entregue' && t.prazo).forEach(t => {
        const date = new Date(t.prazo);
        const monthYear = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
        monthlyProductivity[monthYear] = (monthlyProductivity[monthYear] || 0) + 1;
    });
    const sortedMonths = Object.keys(monthlyProductivity).sort();
    const productivityLabels = sortedMonths.map(my => {
        const [year, month] = my.split('-');
        return `${new Date(year, month - 1).toLocaleString('pt-BR', { month: 'short' })}/${year.slice(2)}`;
    });
    const productivityData = sortedMonths.map(my => monthlyProductivity[my]);
    renderChart('productivityChart', 'line', productivityLabels, productivityData, 'Produtividade Mensal', productivityChartInstance);
};

const renderChart = (canvasId, type, labels, data, title, chartInstance) => {
    const ctx = document.getElementById(canvasId).getContext('2d');
    if (chartInstance) {
        chartInstance.destroy();
    }
    chartInstance = new Chart(ctx, {
        type: type,
        data: {
            labels: labels,
            datasets: [{
                label: title,
                data: data,
                backgroundColor: type === 'pie' ? [
                    '#4A67A1', '#C8A2C8', '#6C757D', '#28A745', '#007BFF', '#DC3545'
                ] : 'rgba(74, 103, 161, 0.6)',
                borderColor: type === 'pie' ? [
                    '#4A67A1', '#C8A2C8', '#6C757D', '#28A745', '#007BFF', '#DC3545'
                ] : 'rgba(74, 103, 161, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: title
                }
            },
            scales: type !== 'pie' ? {
                y: {
                    beginAtZero: true
                }
            } : {}
        }
    });
    // Retorna a instância para que possa ser armazenada e destruída se necessário
    if (canvasId === 'statusChart') statusChartInstance = chartInstance;
    else if (canvasId === 'clientChart') clientChartInstance = chartInstance;
    else if (canvasId === 'redactorChart') redactorChartInstance = chartInstance;
    else if (canvasId === 'productivityChart') productivityChartInstance = chartInstance;
};

// Funções para Configurações
const saveSettings = () => {
    const appName = document.getElementById('appName').value;
    const itemsPerPage = document.getElementById('itemsPerPage').value;
    const emailNotifications = document.getElementById('emailNotifications').checked;
    const deadlineReminders = document.getElementById('deadlineReminders').checked;

    // Aqui você enviaria essas configurações para um backend ou as salvaria localmente
    console.log('Configurações salvas:', { appName, itemsPerPage, emailNotifications, deadlineReminders });
    showMessage('Sucesso', 'Configurações salvas com sucesso!');
};

const exportAllData = () => {
    const data = {
        textos: textos,
        clientes: clientes,
        redatores: redatores,
        guestPosts: guestPosts
    };
    const dataStr = JSON.stringify(data, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'b20_data_export.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showMessage('Exportar Dados', 'Todos os dados foram exportados com sucesso!');
};

const importAllData = (event) => {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                textos = importedData.textos || [];
                clientes = importedData.clientes || [];
                redatores = importedData.redatores || [];
                guestPosts = importedData.guestPosts || [];
                showMessage('Importar Dados', 'Dados importados com sucesso! A página será recarregada.');
                setTimeout(() => location.reload(), 1500); // Recarrega para aplicar os dados
            } catch (error) {
                showMessage('Erro na Importação', 'Não foi possível importar os dados. Verifique o formato do arquivo JSON.');
                console.error('Erro ao importar dados:', error);
            }
        };
        reader.readAsText(file);
    }
};

const resetAllData = () => {
    textos = [];
    clientes = [];
    redatores = [];
    guestPosts = [];
    showMessage('Dados Resetados', 'Todos os dados foram resetados. A página será recarregada.');
    setTimeout(() => location.reload(), 1500);
};

// Funções para Kanban (Drag and Drop)
let dragged;

const handleDragStart = (event) => {
    dragged = event.target;
    event.dataTransfer.setData('text/plain', event.target.dataset.id);
    event.dataTransfer.effectAllowed = 'move';
    event.target.classList.add('dragging');
};

const handleDragOver = (event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
    const target = event.target.closest('.kanban-tasks');
    if (target) {
        target.classList.add('drag-over');
    }
};

const handleDragLeave = (event) => {
    const target = event.target.closest('.kanban-tasks');
    if (target) {
        target.classList.remove('drag-over');
    }
};

const handleDrop = (event) => {
    event.preventDefault();
    const taskId = event.dataTransfer.getData('text/plain');
    const targetColumn = event.target.closest('.kanban-tasks');

    if (targetColumn && dragged) {
        targetColumn.classList.remove('drag-over');
        const newStatus = targetColumn.id.replace('kanban-', '');
        const taskIndex = textos.findIndex(t => t.id === taskId);
        if (taskIndex !== -1) {
            textos[taskIndex].status = newStatus;
            targetColumn.appendChild(dragged);
            showMessage('Status Atualizado', `Texto "${textos[taskIndex].titulo}" movido para ${newStatus.replace('_', ' ')}.`);
        }
    }
    dragged.classList.remove('dragging');
};

const handleDragEnd = (event) => {
    event.target.classList.remove('dragging');
    document.querySelectorAll('.kanban-tasks').forEach(col => col.classList.remove('drag-over'));
};

const renderKanbanTasks = () => {
    // Limpa todas as colunas
    document.getElementById('kanban-a_fazer').innerHTML = '';
    document.getElementById('kanban-em_andamento').innerHTML = '';
    document.getElementById('kanban-feito').innerHTML = '';
    document.getElementById('kanban-revisado').innerHTML = '';
    document.getElementById('kanban-entregue').innerHTML = '';
    document.getElementById('kanban-upload_feito').innerHTML = '';

    textos.forEach(texto => {
        const taskCard = document.createElement('div');
        taskCard.className = 'kanban-task-card';
        taskCard.setAttribute('draggable', 'true');
        taskCard.dataset.id = texto.id;
        taskCard.innerHTML = `
            <h4>${texto.titulo}</h4>
            <p>Cliente: ${clientes.find(c => c.id === texto.clienteId)?.nome || 'N/A'}</p>
            <p>Redator: ${redatores.find(r => r.id === texto.redatorId)?.nome || 'N/A'}</p>
            <div class="task-meta">
                <span>Prazo: ${texto.prazo || 'N/A'}</span>
                <span class="task-status status-${texto.status}">${texto.status.replace('_', ' ')}</span>
            </div>
            <div class="actions mt-2">
                <button class="btn btn-sm btn-secondary" onclick="editTexto('${texto.id}')">Editar</button>
                <button class="btn btn-sm btn-danger" onclick="deleteTexto('${texto.id}')">Excluir</button>
            </div>
        `;
        taskCard.addEventListener('dragstart', handleDragStart);
        taskCard.addEventListener('dragend', handleDragEnd);

        const targetColumn = document.getElementById(`kanban-${texto.status}`);
        if (targetColumn) {
            targetColumn.appendChild(taskCard);
        }
    });

    // Adiciona event listeners de drag and drop às colunas
    document.querySelectorAll('.kanban-tasks').forEach(column => {
        column.addEventListener('dragover', handleDragOver);
        column.addEventListener('dragleave', handleDragLeave);
        column.addEventListener('drop', handleDrop);
    });
};

// Inicialização
let currentView = 'dashboard';

document.addEventListener('DOMContentLoaded', () => {
    // Carregar dados iniciais (exemplo)
    clientes.push({ id: 'c1', nome: 'Cliente A', contato: 'cliente.a@email.com' });
    clientes.push({ id: 'c2', nome: 'Cliente B', contato: 'cliente.b@email.com' });
    redatores.push({ id: 'r1', nome: 'Redator X', especialidade: 'SEO' });
    redatores.push({ id: 'r2', nome: 'Redator Y', especialidade: 'Marketing' });
    textos.push({ id: 't1', titulo: 'Artigo sobre IA', clienteId: 'c1', redatorId: 'r1', prazo: '2025-08-15', status: 'a_fazer', uploadBy: 'B20', uploadDone: false, onDemand: false, notas: '' });
    textos.push({ id: 't2', titulo: 'Ebook de Vendas', clienteId: 'c2', redatorId: 'r2', prazo: '2025-08-20', status: 'em_andamento', uploadBy: 'B20', uploadDone: false, onDemand: true, notas: 'Urgente!' });
    textos.push({ id: 't3', titulo: 'Post para Blog', clienteId: 'c1', redatorId: 'r1', prazo: '2025-08-05', status: 'feito', uploadBy: 'B20', uploadDone: false, onDemand: false, notas: '' });
    textos.push({ id: 't4', titulo: 'Case Study', clienteId: 'c2', redatorId: 'r2', prazo: '2025-07-25', status: 'entregue', uploadBy: 'B20', uploadDone: true, onDemand: false, notas: '' });
    textos.push({ id: 't5', titulo: 'Relatório Anual', clienteId: 'c1', redatorId: 'r1', prazo: '2025-08-10', status: 'revisado', uploadBy: 'B20', uploadDone: false, onDemand: false, notas: 'Aguardando feedback' });
    textos.push({ id: 't6', titulo: 'Infográfico', clienteId: 'c2', redatorId: 'r2', prazo: '2025-08-12', status: 'upload_feito', uploadBy: 'B20', uploadDone: true, onDemand: false, notas: 'Publicado no site' });

    guestPosts.push({ id: 'gp1', titulo: 'Guia de SEO Avançado', clienteId: 'c1', url: 'https://blogparceiro.com/seo-avancado', dataPublicacao: '2025-07-01', status: 'publicado', domainAuthority: 60, backlink: 'https://seusite.com/pagina-seo', notas: '' });

    // Event listeners para navegação na sidebar
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', function() {
            document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            currentView = this.dataset.view;
            views[currentView]();
        });
    });

    // Event listeners para modais
    document.querySelectorAll('[data-close]').forEach(button => {
        button.addEventListener('click', function() {
            closeModal(this.dataset.close.replace('#', ''));
        });
    });

    document.getElementById('btnAddTexto').onclick = () => {
        document.getElementById('formTexto').reset();
        document.getElementById('modalTextoTitle').innerText = 'Novo Texto';
        document.getElementById('textoId').value = '';
        // Preencher selects de cliente e redator
        const clienteSelect = document.getElementById('textoCliente');
        clienteSelect.innerHTML = '';
        clientes.forEach(c => {
            const option = document.createElement('option');
            option.value = c.id;
            option.innerText = c.nome;
            clienteSelect.appendChild(option);
        });
        const redatorSelect = document.getElementById('textoRedator');
        redatorSelect.innerHTML = '<option value="">— Definir depois —</option>';
        redatores.forEach(r => {
            const option = document.createElement('option');
            option.value = r.id;
            option.innerText = r.nome;
            redatorSelect.appendChild(option);
        });
        openModal('modalTexto');
    };

    document.getElementById('formTexto').onsubmit = saveTexto;
    document.getElementById('formCliente').onsubmit = saveCliente;
    document.getElementById('formRedator').onsubmit = saveRedator;
    document.getElementById('formGuestPost').onsubmit = saveGuestPost;

    // Renderiza a view inicial
    views[currentView]();

    // Atualiza o mês atual no header
    const date = new Date();
    document.getElementById('currentMonth').innerText = date.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });
});

// Expor funções para o escopo global para uso em onclick/onchange no HTML
window.editTexto = editTexto;
window.deleteTexto = deleteTexto;
window.editCliente = editCliente;
window.deleteCliente = deleteCliente;
window.editRedator = editRedator;
window.deleteRedator = deleteRedator;
window.editGuestPost = editGuestPost;
window.deleteGuestPost = deleteGuestPost;
window.exportAllData = exportAllData;
window.importAllData = importAllData;
window.resetAllData = resetAllData;
window.saveSettings = saveSettings;
window.generateReports = generateReports;




// Função para mostrar dashboard específico do cliente
const showClientDashboard = (clienteId) => {
    const cliente = dataManager.getClienteById(clienteId);
    const stats = dataManager.getClienteStats(clienteId);
    const projetos = dataManager.getProjetosByCliente(clienteId);
    const textos = dataManager.getTextosByCliente(clienteId);
    
    document.getElementById('pageTitle').innerText = `Dashboard - ${cliente.nome}`;
    document.getElementById('view').innerHTML = `
        <div class="view-section">
            <div class="client-header">
                <h2>${cliente.nome}</h2>
                <button class="btn btn-secondary" onclick="views.dashboard()">
                    <i class="fas fa-arrow-left"></i> Voltar ao Dashboard Geral
                </button>
            </div>
            <div class="client-info">
                <p><strong>Contato:</strong> ${cliente.contato}</p>
                <p><strong>Resumo:</strong> ${cliente.resumo}</p>
                <p><strong>Observações:</strong> ${cliente.observacoes}</p>
            </div>
        </div>
        
        <div class="view-section">
            <h3>Métricas do Cliente</h3>
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h4>Total de Textos</h4>
                    <p class="value">${stats.totalTextos}</p>
                </div>
                <div class="dashboard-card">
                    <h4>Textos Ativos</h4>
                    <p class="value">${stats.textosAtivos}</p>
                </div>
                <div class="dashboard-card">
                    <h4>Textos Entregues</h4>
                    <p class="value">${stats.textosEntregues}</p>
                </div>
                <div class="dashboard-card">
                    <h4>Projetos Ativos</h4>
                    <p class="value">${stats.projetosAtivos}</p>
                </div>
            </div>
        </div>
        
        <div class="view-section">
            <h3>Distribuição por Status</h3>
            <canvas id="clientStatusChart"></canvas>
        </div>
        
        <div class="view-section">
            <h3>Projetos do Cliente</h3>
            <div class="projects-list">
                ${projetos.map(projeto => `
                    <div class="project-summary">
                        <h4>${projeto.nome}</h4>
                        <p>${projeto.descricao}</p>
                        <div class="project-meta">
                            <span>Status: ${projeto.status}</span>
                            <span>Textos: ${textos.filter(t => t.projetoId === projeto.id).length}</span>
                        </div>
                        <button class="btn btn-sm btn-primary" onclick="showProjectDetails('${projeto.id}')">
                            Ver Detalhes
                        </button>
                    </div>
                `).join('')}
            </div>
        </div>
        
        <div class="view-section">
            <h3>Próximos Prazos</h3>
            <div class="deadlines-list">
                ${stats.proximosPrazos.map(texto => `
                    <div class="deadline-item ${texto.diasRestantes <= 3 ? 'urgent' : ''}">
                        <h5>${texto.titulo}</h5>
                        <p>Prazo: ${texto.prazo} (${texto.diasRestantes} dias)</p>
                        <span class="status-badge ${texto.status}">${getStatusLabel(texto.status)}</span>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    // Renderizar gráfico de status do cliente
    setTimeout(() => {
        renderClientStatusChart(stats.statusDistribution);
    }, 100);
};

// Função para mostrar detalhes do projeto
const showProjectDetails = (projetoId) => {
    const projeto = dataManager.getProjetoById(projetoId);
    const cliente = dataManager.getClienteById(projeto.clienteId);
    const textos = dataManager.getTextosByProjeto(projetoId);
    const documentos = dataManager.getDocumentosByProjeto(projetoId);
    
    document.getElementById('pageTitle').innerText = `Projeto - ${projeto.nome}`;
    document.getElementById('view').innerHTML = `
        <div class="view-section">
            <div class="project-header">
                <h2>${projeto.nome}</h2>
                <div class="project-actions">
                    <button class="btn btn-secondary" onclick="views.projetos()">
                        <i class="fas fa-arrow-left"></i> Voltar aos Projetos
                    </button>
                    <button class="btn btn-primary" onclick="editProjeto('${projeto.id}')">
                        <i class="fas fa-edit"></i> Editar Projeto
                    </button>
                </div>
            </div>
            
            <div class="project-details">
                <div class="detail-section">
                    <h3>Informações Gerais</h3>
                    <p><strong>Cliente:</strong> ${cliente.nome}</p>
                    <p><strong>Descrição:</strong> ${projeto.descricao}</p>
                    <p><strong>Período:</strong> ${projeto.dataInicio} até ${projeto.dataFim}</p>
                    <p><strong>Status:</strong> <span class="project-status ${projeto.status}">${projeto.status.toUpperCase()}</span></p>
                </div>
                
                <div class="detail-section">
                    <h3>Resumo do Projeto</h3>
                    <div class="editable-content">
                        <textarea id="projectSummary" class="form-control" rows="4">${projeto.resumo}</textarea>
                        <button class="btn btn-sm btn-primary mt-2" onclick="updateProjectSummary('${projeto.id}')">
                            Salvar Resumo
                        </button>
                    </div>
                </div>
                
                <div class="detail-section">
                    <h3>Observações</h3>
                    <div class="editable-content">
                        <textarea id="projectObservations" class="form-control" rows="3">${projeto.observacoes}</textarea>
                        <button class="btn btn-sm btn-primary mt-2" onclick="updateProjectObservations('${projeto.id}')">
                            Salvar Observações
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="view-section">
            <h3>Textos do Projeto</h3>
            <div class="texts-list">
                ${textos.map(texto => `
                    <div class="text-item">
                        <div class="text-header">
                            <h4>${texto.titulo}</h4>
                            <span class="status-badge ${texto.status}">${getStatusLabel(texto.status)}</span>
                        </div>
                        <p><strong>Redator:</strong> ${redatores.find(r => r.id === texto.redatorId)?.nome || 'N/A'}</p>
                        <p><strong>Prazo:</strong> ${texto.prazo}</p>
                        <div class="text-notes">
                            <h5>Notas:</h5>
                            <textarea id="notes_${texto.id}" class="form-control" rows="2">${texto.notas || ''}</textarea>
                            <button class="btn btn-sm btn-primary mt-1" onclick="updateTextNotes('${texto.id}')">
                                Salvar Notas
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
        
        <div class="view-section">
            <h3>Documentos do Projeto</h3>
            <div class="documents-section">
                <button class="btn btn-primary mb-3" onclick="openUploadModal('${projeto.id}')">
                    <i class="fas fa-upload"></i> Adicionar Documento
                </button>
                <div class="documents-list">
                    ${documentos.map(doc => `
                        <div class="document-item">
                            <div class="document-info">
                                <h5>${doc.nome}</h5>
                                <p>${doc.descricao}</p>
                                <small>Tamanho: ${doc.tamanho} | Upload: ${doc.dataUpload}</small>
                            </div>
                            <div class="document-actions">
                                <button class="btn btn-sm btn-secondary" onclick="downloadDocument('${doc.id}')">
                                    <i class="fas fa-download"></i> Download
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="deleteDocument('${doc.id}')">
                                    <i class="fas fa-trash"></i> Excluir
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;
};

// Funções auxiliares
const getStatusLabel = (status) => {
    const labels = {
        'a_fazer': 'A Fazer',
        'em_andamento': 'Em Andamento',
        'feito': 'Feito',
        'revisado': 'Revisado',
        'entregue': 'Entregue',
        'upload_feito': 'Upload Feito'
    };
    return labels[status] || status;
};

const updateProjectSummary = (projetoId) => {
    const summary = document.getElementById('projectSummary').value;
    dataManager.updateProjeto(projetoId, { resumo: summary });
    alert('Resumo atualizado com sucesso!');
};

const updateProjectObservations = (projetoId) => {
    const observations = document.getElementById('projectObservations').value;
    dataManager.updateProjeto(projetoId, { observacoes: observations });
    alert('Observações atualizadas com sucesso!');
};

const updateTextNotes = (textoId) => {
    const notes = document.getElementById(`notes_${textoId}`).value;
    dataManager.updateTextoNotas(textoId, notes);
    alert('Notas atualizadas com sucesso!');
};

const renderClientStatusChart = (statusDistribution) => {
    const ctx = document.getElementById('clientStatusChart').getContext('2d');
    const labels = Object.keys(statusDistribution).map(status => getStatusLabel(status));
    const data = Object.values(statusDistribution);
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: [
                    '#FFD700', // A Fazer
                    '#87CEEB', // Em Andamento
                    '#90EE90', // Feito
                    '#DDA0DD', // Revisado
                    '#4169E1', // Entregue
                    '#DC143C'  // Upload Feito
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
};

// Inicializar dados quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
    initializeDataFromManager();
    // Resto da inicialização...
});


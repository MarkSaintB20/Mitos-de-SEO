// Gráficos adicionais para o dashboard principal

// Função para renderizar gráfico de produtividade por redator
const renderRedatorProductivityChart = () => {
    const ctx = document.getElementById('redatorProductivityChart');
    if (!ctx) return;

    const redatorStats = redatores.map(redator => {
        const textosRedator = textos.filter(t => t.redatorId === redator.id);
        const textosEntregues = textosRedator.filter(t => ['entregue', 'upload_feito'].includes(t.status));
        const textosAtivos = textosRedator.filter(t => !['entregue', 'upload_feito'].includes(t.status));
        
        return {
            nome: redator.nome,
            entregues: textosEntregues.length,
            ativos: textosAtivos.length,
            total: textosRedator.length
        };
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: redatorStats.map(r => r.nome),
            datasets: [
                {
                    label: 'Textos Entregues',
                    data: redatorStats.map(r => r.entregues),
                    backgroundColor: '#28a745',
                    borderColor: '#1e7e34',
                    borderWidth: 1
                },
                {
                    label: 'Textos Ativos',
                    data: redatorStats.map(r => r.ativos),
                    backgroundColor: '#ffc107',
                    borderColor: '#e0a800',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Produtividade por Redator',
                    font: {
                        family: 'Times New Roman',
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                },
                x: {
                    ticks: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                }
            }
        }
    });
};

// Função para renderizar gráfico de distribuição de status
const renderStatusDistributionChart = () => {
    const ctx = document.getElementById('statusDistributionChart');
    if (!ctx) return;

    const statusCounts = {
        'a_fazer': 0,
        'em_andamento': 0,
        'feito': 0,
        'revisado': 0,
        'entregue': 0,
        'upload_feito': 0
    };

    textos.forEach(texto => {
        if (statusCounts.hasOwnProperty(texto.status)) {
            statusCounts[texto.status]++;
        }
    });

    const labels = Object.keys(statusCounts).map(status => {
        const statusLabels = {
            'a_fazer': 'A Fazer',
            'em_andamento': 'Em Andamento',
            'feito': 'Feito',
            'revisado': 'Revisado',
            'entregue': 'Entregue',
            'upload_feito': 'Upload Feito'
        };
        return statusLabels[status];
    });

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: Object.values(statusCounts),
                backgroundColor: [
                    '#FFD700', // A Fazer
                    '#87CEEB', // Em Andamento
                    '#90EE90', // Feito
                    '#DDA0DD', // Revisado
                    '#4169E1', // Entregue
                    '#DC143C'  // Upload Feito
                ],
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Distribuição por Status',
                    font: {
                        family: 'Times New Roman',
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        font: {
                            family: 'Times New Roman'
                        },
                        padding: 15
                    }
                }
            }
        }
    });
};

// Função para renderizar gráfico de textos por cliente (melhorado)
const renderClientTextChart = () => {
    const ctx = document.getElementById('clientTextChart');
    if (!ctx) return;

    const clientStats = clientes.map(cliente => {
        const textosCliente = textos.filter(t => t.clienteId === cliente.id);
        const textosEntregues = textosCliente.filter(t => ['entregue', 'upload_feito'].includes(t.status));
        const textosAtivos = textosCliente.filter(t => !['entregue', 'upload_feito'].includes(t.status));
        
        return {
            nome: cliente.nome,
            entregues: textosEntregues.length,
            ativos: textosAtivos.length,
            total: textosCliente.length
        };
    });

    new Chart(ctx, {
        type: 'horizontalBar',
        data: {
            labels: clientStats.map(c => c.nome),
            datasets: [
                {
                    label: 'Textos Entregues',
                    data: clientStats.map(c => c.entregues),
                    backgroundColor: '#4A67A1',
                    borderColor: '#3a5490',
                    borderWidth: 1
                },
                {
                    label: 'Textos Ativos',
                    data: clientStats.map(c => c.ativos),
                    backgroundColor: '#C8A2C8',
                    borderColor: '#b891b8',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Textos por Cliente',
                    font: {
                        family: 'Times New Roman',
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                }
            },
            scales: {
                y: {
                    ticks: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                },
                x: {
                    beginAtZero: true,
                    ticks: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                }
            }
        }
    });
};

// Função para renderizar gráfico de performance mensal
const renderMonthlyPerformanceChart = () => {
    const ctx = document.getElementById('monthlyPerformanceChart');
    if (!ctx) return;

    // Obter dados dos últimos 6 meses
    const months = [];
    const currentDate = new Date();
    
    for (let i = 5; i >= 0; i--) {
        const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
        months.push({
            label: date.toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' }),
            month: date.getMonth(),
            year: date.getFullYear()
        });
    }

    const monthlyData = months.map(month => {
        const textosDoMes = textos.filter(texto => {
            if (!texto.prazo) return false;
            const prazoDate = new Date(texto.prazo);
            return prazoDate.getMonth() === month.month && prazoDate.getFullYear() === month.year;
        });

        const entregues = textosDoMes.filter(t => ['entregue', 'upload_feito'].includes(t.status)).length;
        const atrasados = textosDoMes.filter(t => {
            const prazoDate = new Date(t.prazo);
            return prazoDate < new Date() && !['entregue', 'upload_feito'].includes(t.status);
        }).length;

        return {
            entregues,
            atrasados,
            total: textosDoMes.length
        };
    });

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: months.map(m => m.label),
            datasets: [
                {
                    label: 'Textos Entregues',
                    data: monthlyData.map(d => d.entregues),
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'Textos Atrasados',
                    data: monthlyData.map(d => d.atrasados),
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    fill: true,
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Performance dos Últimos 6 Meses',
                    font: {
                        family: 'Times New Roman',
                        size: 16,
                        weight: 'bold'
                    }
                },
                legend: {
                    position: 'top',
                    labels: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                },
                x: {
                    ticks: {
                        font: {
                            family: 'Times New Roman'
                        }
                    }
                }
            }
        }
    });
};

// Função para renderizar todos os gráficos adicionais
const renderAdditionalCharts = () => {
    setTimeout(() => {
        renderRedatorProductivityChart();
        renderStatusDistributionChart();
        renderClientTextChart();
        renderMonthlyPerformanceChart();
    }, 100);
};


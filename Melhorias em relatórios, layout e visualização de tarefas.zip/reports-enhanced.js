// Funções aprimoradas para relatórios
const renderAllReportCharts = () => {
    renderStatusChart();
    renderClientChart();
    renderRedatorChart();
    renderMonthlyChart();
    renderDeadlineChart();
    renderDeliveryChart();
    renderProjectProgressChart();
    renderWorkloadChart();
};

const renderDeadlineChart = () => {
    const ctx = document.getElementById('deadlineChart').getContext('2d');
    const deadlineData = getDeadlineDistribution();
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Atrasados', 'Hoje', 'Próximos 3 dias', 'Próximos 7 dias', 'Mais de 7 dias'],
            datasets: [{
                label: 'Quantidade de Textos',
                data: [
                    deadlineData.overdue,
                    deadlineData.today,
                    deadlineData.next3Days,
                    deadlineData.next7Days,
                    deadlineData.moreThan7Days
                ],
                backgroundColor: [
                    '#DC143C', // Atrasados - Vermelho
                    '#FF8C00', // Hoje - Laranja
                    '#FFD700', // 3 dias - Amarelo
                    '#90EE90', // 7 dias - Verde claro
                    '#87CEEB'  // Mais de 7 - Azul claro
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1
                    }
                }
            }
        }
    });
};

const renderDeliveryChart = () => {
    const ctx = document.getElementById('deliveryChart').getContext('2d');
    const deliveryData = getDeliveryRateData();
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['No Prazo', 'Atrasados', 'Pendentes'],
            datasets: [{
                data: [
                    deliveryData.onTime,
                    deliveryData.late,
                    deliveryData.pending
                ],
                backgroundColor: [
                    '#90EE90', // No prazo - Verde
                    '#DC143C', // Atrasados - Vermelho
                    '#FFD700'  // Pendentes - Amarelo
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
};

const renderProjectProgressChart = () => {
    const ctx = document.getElementById('projectProgressChart').getContext('2d');
    const projectData = getProjectProgressData();
    
    new Chart(ctx, {
        type: 'horizontalBar',
        data: {
            labels: projectData.labels,
            datasets: [{
                label: 'Progresso (%)',
                data: projectData.progress,
                backgroundColor: '#4A67A1'
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
};

const renderWorkloadChart = () => {
    const ctx = document.getElementById('workloadChart').getContext('2d');
    const workloadData = getWorkloadData();
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: workloadData.labels,
            datasets: [{
                label: 'Textos Ativos',
                data: workloadData.activeTexts,
                backgroundColor: '#4A67A1'
            }, {
                label: 'Textos Entregues',
                data: workloadData.deliveredTexts,
                backgroundColor: '#90EE90'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
};

// Funções auxiliares para cálculos de dados
const getDeadlineDistribution = () => {
    const hoje = new Date();
    const distribution = {
        overdue: 0,
        today: 0,
        next3Days: 0,
        next7Days: 0,
        moreThan7Days: 0
    };
    
    textos.filter(t => !['entregue', 'upload_feito'].includes(t.status)).forEach(texto => {
        if (!texto.prazo) return;
        
        const prazo = new Date(texto.prazo);
        const diffDays = Math.ceil((prazo - hoje) / (1000 * 60 * 60 * 24));
        
        if (diffDays < 0) {
            distribution.overdue++;
        } else if (diffDays === 0) {
            distribution.today++;
        } else if (diffDays <= 3) {
            distribution.next3Days++;
        } else if (diffDays <= 7) {
            distribution.next7Days++;
        } else {
            distribution.moreThan7Days++;
        }
    });
    
    return distribution;
};

const getDeliveryRateData = () => {
    const hoje = new Date();
    const data = {
        onTime: 0,
        late: 0,
        pending: 0
    };
    
    textos.forEach(texto => {
        if (!texto.prazo) return;
        
        const prazo = new Date(texto.prazo);
        const isDelivered = ['entregue', 'upload_feito'].includes(texto.status);
        const isOverdue = prazo < hoje;
        
        if (isDelivered) {
            data.onTime++;
        } else if (isOverdue) {
            data.late++;
        } else {
            data.pending++;
        }
    });
    
    return data;
};

const getProjectProgressData = () => {
    const data = {
        labels: [],
        progress: []
    };
    
    projetos.forEach(projeto => {
        const textosProject = textos.filter(t => t.projetoId === projeto.id);
        const textosCompletos = textosProject.filter(t => ['entregue', 'upload_feito'].includes(t.status));
        const progress = textosProject.length > 0 ? Math.round((textosCompletos.length / textosProject.length) * 100) : 0;
        
        data.labels.push(projeto.nome);
        data.progress.push(progress);
    });
    
    return data;
};

const getWorkloadData = () => {
    const data = {
        labels: [],
        activeTexts: [],
        deliveredTexts: []
    };
    
    redatores.forEach(redator => {
        const textosRedator = textos.filter(t => t.redatorId === redator.id);
        const textosAtivos = textosRedator.filter(t => !['entregue', 'upload_feito'].includes(t.status));
        const textosEntregues = textosRedator.filter(t => ['entregue', 'upload_feito'].includes(t.status));
        
        data.labels.push(redator.nome);
        data.activeTexts.push(textosAtivos.length);
        data.deliveredTexts.push(textosEntregues.length);
    });
    
    return data;
};

const getOverdueTexts = () => {
    const hoje = new Date();
    return textos.filter(texto => {
        if (!texto.prazo || ['entregue', 'upload_feito'].includes(texto.status)) return false;
        return new Date(texto.prazo) < hoje;
    });
};

const getAverageWordCount = () => {
    const textosComPalavras = textos.filter(t => t.numerosPalavras);
    if (textosComPalavras.length === 0) return 0;
    
    const total = textosComPalavras.reduce((sum, t) => sum + t.numerosPalavras, 0);
    return Math.round(total / textosComPalavras.length);
};

const getRevisionRate = () => {
    const textosComRevisao = textos.filter(t => t.revisoes && t.revisoes.length > 0);
    return textos.length > 0 ? Math.round((textosComRevisao.length / textos.length) * 100) : 0;
};

const getUpcomingDeadlines = () => {
    const hoje = new Date();
    return textos
        .filter(t => t.prazo && !['entregue', 'upload_feito'].includes(t.status))
        .sort((a, b) => new Date(a.prazo) - new Date(b.prazo))
        .slice(0, 10); // Próximos 10 prazos
};

const getDaysUntilDeadline = (prazo) => {
    const hoje = new Date();
    const deadline = new Date(prazo);
    return Math.ceil((deadline - hoje) / (1000 * 60 * 60 * 24));
};

const generateCustomReport = () => {
    const clienteId = document.getElementById('clienteFilter').value;
    const redatorId = document.getElementById('redatorFilter').value;
    const periodo = document.getElementById('periodoFilter').value;
    const projetoId = document.getElementById('projetoFilter').value;
    
    // Filtrar dados baseado nos filtros selecionados
    let filteredTextos = textos;
    
    if (clienteId) {
        filteredTextos = filteredTextos.filter(t => t.clienteId === clienteId);
    }
    
    if (redatorId) {
        filteredTextos = filteredTextos.filter(t => t.redatorId === redatorId);
    }
    
    if (projetoId) {
        filteredTextos = filteredTextos.filter(t => t.projetoId === projetoId);
    }
    
    if (periodo) {
        const hoje = new Date();
        let dataLimite;
        
        switch (periodo) {
            case 'ultimo_mes':
                dataLimite = new Date(hoje.getFullYear(), hoje.getMonth() - 1, hoje.getDate());
                break;
            case 'ultimo_trimestre':
                dataLimite = new Date(hoje.getFullYear(), hoje.getMonth() - 3, hoje.getDate());
                break;
            case 'ultimo_ano':
                dataLimite = new Date(hoje.getFullYear() - 1, hoje.getMonth(), hoje.getDate());
                break;
        }
        
        if (dataLimite) {
            filteredTextos = filteredTextos.filter(t => new Date(t.prazo) >= dataLimite);
        }
    }
    
    // Atualizar gráficos com dados filtrados
    updateChartsWithFilteredData(filteredTextos);
    
    // Mostrar resumo do relatório filtrado
    showFilteredReportSummary(filteredTextos);
};

const updateChartsWithFilteredData = (filteredTextos) => {
    // Temporariamente substituir dados globais
    const originalTextos = textos;
    textos = filteredTextos;
    
    // Re-renderizar gráficos
    renderAllReportCharts();
    
    // Restaurar dados originais
    textos = originalTextos;
};

const showFilteredReportSummary = (filteredTextos) => {
    const summary = document.createElement('div');
    summary.className = 'filtered-report-summary';
    summary.innerHTML = `
        <h4>Resumo do Relatório Filtrado</h4>
        <div class="summary-stats">
            <div class="summary-stat">
                <span class="stat-value">${filteredTextos.length}</span>
                <span class="stat-label">Total de Textos</span>
            </div>
            <div class="summary-stat">
                <span class="stat-value">${filteredTextos.filter(t => ['entregue', 'upload_feito'].includes(t.status)).length}</span>
                <span class="stat-label">Textos Entregues</span>
            </div>
            <div class="summary-stat">
                <span class="stat-value">${filteredTextos.filter(t => !['entregue', 'upload_feito'].includes(t.status)).length}</span>
                <span class="stat-label">Textos Pendentes</span>
            </div>
        </div>
    `;
    
    // Remover resumo anterior se existir
    const existingSummary = document.querySelector('.filtered-report-summary');
    if (existingSummary) {
        existingSummary.remove();
    }
    
    // Adicionar novo resumo
    document.querySelector('.filters-section').appendChild(summary);
};

